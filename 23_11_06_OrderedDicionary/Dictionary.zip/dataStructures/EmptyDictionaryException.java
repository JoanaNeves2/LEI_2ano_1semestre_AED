package dataStructures;

public class EmptyDictionaryException extends RuntimeException{

    static final long serialVersionUID = 0L;
}

