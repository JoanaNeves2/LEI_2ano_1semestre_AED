package dataStructures;

/**
 * CollisionList implementation
 * 
 * @author Joao Viana, Tiago Guerra
 * @version 1.0
 * @param <K> Generic Key
 * @param <V> Generic Value
 */

public class CollisionList<K, V> implements Dictionary<K, V> {

	/*
	 * Memory of the collisionList
	 */
	private List<Entry<K, V>> collisionList;

	/*
	 * 
	 */
	public CollisionList() {
		collisionList = new DoublyLinkedList<Entry<K, V>>();

	}

	@Override
	public boolean isEmpty() {

		return collisionList.isEmpty();
	}

	@Override
	public int size() {

		return collisionList.size();
	}

	@Override
	public V find(K key) {
		int position = findIndex(key);
		return get(position);
	}

	@Override
	public V insert(K key, V value) {

		V previousValue = find(key);

		if (previousValue != null) {

			((EntryClass<K, V>) getEntry(key)).setValue(value);

		} else {
			collisionList.addFirst(new EntryClass<K, V>(key, value));
		}
		return previousValue;
	}

	@Override
	public V remove(K key) {

		int position = findIndex(key);
		V previousValue = get(position);
		if (previousValue != null) {
			collisionList.remove(position);

		}
		return previousValue;
	}

	@Override
	public Iterator<Entry<K, V>> iterator() {

		return collisionList.iterator();
	}

	/**
	 * Find Entry Index
	 * 
	 * @param key with which the specified value
	 * @return index position
	 */

	private int findIndex(K key) {

		Iterator<Entry<K, V>> it = iterator();
		for (int i = 0; it.hasNext(); i++) {
			if (it.next().getKey().equals(key)) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * Method that finds entry by giving the key
	 * 
	 * @param key with which the specified value
	 * @return entry with the given key
	 */
	private Entry<K, V> getEntry(K key) {

		Iterator<Entry<K, V>> it = iterator();
		while (it.hasNext()) {
			Entry<K, V> entry = it.next();

			if (entry.getKey().equals(key))
				return entry;
		}
		return null;

	}

	/**
	 * If there is an entry in the dictionary whose key is the specified key,returns its value; otherwise, returns null.
	 * 
	 * @param position findIndex position
	 * 
	 * @return value of the entry with the given position
	 */
	private V get(int position) {

		if (position == -1) {
			return null;
		}
		return collisionList.get(position).getValue();
	}
}
