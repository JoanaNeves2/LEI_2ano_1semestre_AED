package dataStructures;

import dataStructures.BinarySearchTree.BSTNode;
/**
 * BinarySearchTree implementation
 * 
 * @author  Joao Viana, Tiago Guerra
 * @param <K> Generic type Key
 * @param <V> Generic type Value
 */
@SuppressWarnings("serial")
public class BSTKeyOrderIterator<K, V> implements Iterator<Entry<K, V>> {
	/**
	 * Root of the given Tree to start to iterate
	 */
	BSTNode<K, V> root;
	
	BSTNode<K, V> currentNode, lastNode;
	/**
	 * Stack of nodes that we will pop later
	 */
	Stack<BSTNode<K, V>> nodes;

	/**
	 * Initializes BSTKeyOrderIterator
	 * @param root root of the given tree
	 */
	public BSTKeyOrderIterator(BSTNode<K, V> root) {
		this.root = root;
		rewind();
	}

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return currentNode != lastNode;
	}

	@Override
	public Entry<K, V> next() throws NoSuchElementException {

		currentNode = nodes.pop();

		if (currentNode.getRight() != null) {

			getMin(currentNode.getRight());
		}

		return currentNode.getEntry();
	}

	@Override
	public void rewind() {
		currentNode = root;
		lastNode = root;
		nodes = new StackInList<BSTNode<K, V>>();
		while (currentNode != null) {
			nodes.push(currentNode);
			currentNode = currentNode.getLeft();
		}
		while (lastNode.getRight() != null) {
			lastNode = lastNode.getRight();
		}

	}

	/**
	 * Get the most left node of the given node
	 * @param node 
	 */
	private void getMin(BSTNode<K, V> node) {
		while (node != null) {
			nodes.push(node);
			node = node.getLeft();
		}
	}

}