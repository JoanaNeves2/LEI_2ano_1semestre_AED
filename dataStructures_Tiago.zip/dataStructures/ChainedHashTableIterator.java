package dataStructures;
/**
 * Chained Hash Tale Iterator implementation
 * @author Joao Viana, Tiago Guerra
 * @version 1.0
 * @param <K> Generic Key
 * @param <V> Generic Value 
 */

@SuppressWarnings("serial")
public class ChainedHashTableIterator<K, V> implements Iterator<Entry<K, V>> {

	/*
	 * Given table to iterate
	 */
	private Dictionary<K, V>[] table;
	/*
	 * Collision list iterator
	 */
	private Iterator<Entry<K, V>> it;

	/*
	 * Table position
	 */
	private int position;

	/*
	 * Number of next called
	 */
	private int current;
	/*
	 * Number of table elements
	 */
	private int numberOfElements;

	private boolean currentCollisionList; // checks if the it iterator is in the same collisionList of the previous
											// next;

	/**
	 * Initializes the ChainedHashTableIterator
	 * @param table table to iterate
	 * @param numberOfElements number of elements of the table
	 */
	public ChainedHashTableIterator(Dictionary<K, V>[] table, int numberOfElements) {
		this.table = table;
		this.numberOfElements = numberOfElements;
		this.rewind();

	}

	@Override
	public boolean hasNext() {
		return current < numberOfElements;
	}

	@Override
	public Entry<K, V> next() throws NoSuchElementException {
		if (!this.hasNext())
			throw new NoSuchElementException();

		Entry<K, V> entry = null;

		while (table[position].isEmpty()) {
			position++;
		}
		if (!currentCollisionList) { // only enters if it is the first time calling iterator on the
										// table[current].iterator
			it = table[position].iterator();
			currentCollisionList = true;

		}

		entry = it.next();

		if (!it.hasNext()) {
			position++;
			currentCollisionList = false;
		}
		current++;
		return entry;

	}

	@Override
	public void rewind() {
		position = 0;
		current = 0;
		it = null;
		currentCollisionList = false;

	}

}
