package dataStructures;

/**
 * Singly linked list Implementation
 * 
 * @author AED Team
 * @version 1.0
 * @param <E> Generic Element
 * 
 */
public class SinglyLinkedList<E> implements List<E> {

	/**
	 * Serial Version UID of the Class
	 */
	static final long serialVersionUID = 0L;

	static class SListNode<E> {
		// Element stored in the node.
		protected E element;
		// (Pointer to) the next node.
		protected SListNode<E> next;

		public SListNode(E elem, SListNode<E> theNext) {
			element = elem;
			next = theNext;
		}

		public SListNode(E theElement) {
			this(theElement, null);
		}

		public E getElement() {
			return element;
		}

		public SListNode<E> getNext() {
			return next;
		}

		public void setElement(E newElement) {
			element = newElement;
		}

		public void setNext(SListNode<E> newNext) {
			next = newNext;
		}

	}

	// Node at the head of the list.
	protected SListNode<E> head;

	// Node at the tail of the list.
	protected SListNode<E> tail;

	// Number of elements in the list.
	protected int currentSize;

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return head == null;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return currentSize;
	}

	@Override
	public Iterator<E> iterator() throws NoElementException {
		return new SinglyLLIterator<E>(head);
	}

	@Override
	public int find(E element) {

		SListNode<E> h = head;
		int i = 0;
		while (element != h.getElement() && i < currentSize) {
			h = h.getNext();
			i++;
		}

		return i;
	}

	@Override
	public E getFirst() throws NoElementException {
		// TODO Auto-generated method stub
		if (this.isEmpty()) {
			throw new NoElementException();
		}
		return head.getElement();
	}

	@Override
	public E getLast() throws NoElementException {
		// TODO Auto-generated method stub
		if (this.isEmpty()) {
			throw new NoElementException();
		}
		return tail.getElement();
	}

	@Override
	public E get(int position) throws InvalidPositionException {
		if (position >= currentSize || position < 0) {
			throw new InvalidPositionException();
		}
		SListNode<E> h = head.getNext();
		E tmp = null;
		if (position == 0) {
			tmp = this.getFirst();
		} else if (position == currentSize - 1) {
			tmp = this.getLast();
		} else {
			for (int i = 1; i < position; i++) {
				h = h.getNext();
			}
			tmp = h.getElement();
		}

		return tmp;
	}

	@Override
	public void addFirst(E element) {
		// TODO Auto-generated method stub
		if (element == null) {
			throw new NoElementException();
		}
		SListNode<E> tmp = new SListNode<E>(element);
		if (head == null) {
			head = tmp;
			tail = tmp;
		} else {
			tmp.setNext(head);
			head = tmp;
		}
		currentSize++;

	}

	@Override
	public void addLast(E element) {
		// TODO Auto-generated method stub
		if (element == null) {
			throw new NoElementException();
		}
		SListNode<E> tmp = new SListNode<E>(element);
		if (head == null) {
			head = tmp;
			tail = tmp;
		} else {
			tmp.setNext(null);
			tail.next = tmp;
			tail = tmp;
		}
		currentSize++;
	}

	@Override
	public void add(int position, E element) throws InvalidPositionException {
		// TODO Auto-generated method stub
		if (position > currentSize || position < 0) {
			throw new InvalidPositionException();
		}
		SListNode<E> h = head;
		if (position == 0) {
			this.addFirst(element);
		} else if (position == currentSize) {
			this.addLast(element);
		} else {
			for (int i = 1; i < position; i++) {
				h = h.getNext();
			}

			SListNode<E> tmp = new SListNode<E>(element);
			tmp.setNext(h.getNext());
			h.setNext(tmp);
			currentSize++;
		}

	}

	@Override
	public E removeFirst() throws NoElementException {
		// TODO Auto-generated method stub
		if (this.isEmpty()) {
			throw new NoElementException();
		}
		E tmp = head.getElement();
		if (currentSize - 1 == 0) {
			head = null;
			tail = null;
		} else {

			head = head.getNext();
			currentSize--;
		}
		return tmp;
	}

	@Override
	public E removeLast() throws NoElementException {
		if (this.isEmpty()) {
			throw new NoElementException();
		}

		SListNode<E> h = head;
		E tmp = head.getElement();
		if (currentSize - 1 == 0) {
			head = null;
			tail = null;
		} else {

			for (int i = 1; i < currentSize - 1; i++) {
				h = h.getNext();
			}
			h.setNext(null);
			tail = h;
			currentSize--;
			tmp = tail.getElement();
		}
		return tmp;
	}

	@Override
	public E remove(int position) throws InvalidPositionException {
		// TODO Auto-generated method stub
		if (position >= currentSize || position < 0) {
			throw new InvalidPositionException();
		}
		SListNode<E> h = head;
		if (position == 0) {
			this.removeFirst();
		} else if (position == currentSize) {
			this.removeLast();
		} else {
			for (int i = 1; i < position; i++) {
				h = h.getNext();
			}
		}
		E tmp = h.getNext().getElement();
		h.setNext(h.getNext().getNext());
		currentSize--;
		return tmp;
	}

	@Override
	public boolean remove(E element) {
		// TODO Auto-generated method stub
		SListNode<E> h = head;

		if (h.getElement() == element) { // remove first
			removeFirstNode();
			return true;

		}
		while (h.getElement() != element && h.getNext() != null) {

			if (h.getNext().getElement() == element) {

				if (h.getNext().getNext() == null ) {
					h.setNext(null);
					tail = h;
					currentSize--;
					return true;
				} else {
					h.setNext(h.getNext().getNext());
					currentSize--;
					return true;
				}
			}

			h = h.getNext();
		}
		return false;
	}

	/**
	 * Removes the first node in the list. Pre-condition: the list is not empty.
	 */
	private void removeFirstNode() {

		if (currentSize - 1 == 0) {
			head = null;
			tail = null;
		} else {
			head = head.getNext();

		}
		currentSize--;

	}
}
