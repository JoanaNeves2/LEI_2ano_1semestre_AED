package exceptions;

public class ArtistWithoutArtworksException extends Exception{
}
