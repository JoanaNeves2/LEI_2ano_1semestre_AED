package exceptions;

public class DoesntExistAnyArtworksSoldException extends Throwable {
}
