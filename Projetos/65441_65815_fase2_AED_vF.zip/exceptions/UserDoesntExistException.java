package exceptions;

public class UserDoesntExistException extends Exception{
}
