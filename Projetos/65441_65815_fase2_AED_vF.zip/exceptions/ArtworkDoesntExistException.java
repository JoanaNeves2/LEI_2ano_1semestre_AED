package exceptions;

public class ArtworkDoesntExistException extends Exception{
}
