package exceptions;

public class AuctionDoesntExistException extends Exception{
}
