package exceptions;

public class ArtworkWithNoBidsException extends Exception{
}
