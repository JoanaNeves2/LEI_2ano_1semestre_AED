package auctionManagement;

import java.io.Serializable;

interface PrivateArtworkInAuction extends ArtworkInAuction, Serializable {

    /**
     * Adds a new bid to both this artworkInAuction's, and its artwork's bids collections
     *
     * @param auction the auction we want to add an artwork
     * @param newBid  the new sales proposal for this artwork
     */
    void addBid(Auction auction, Bid newBid);

    /**
     * Sells the artworks which had valid bids and removes all bids from each bidder (user)
     */
    void close();
}
