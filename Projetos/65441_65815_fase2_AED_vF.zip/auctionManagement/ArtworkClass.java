package auctionManagement;

/**
 * This class represents an artwork.
 * This class manages all the information about each artwork.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public class ArtworkClass implements PrivateArtwork{

    /**
     * Serial Version UID
     */
    private static final long serialVersionUID = 0L;

    //Instance Variables
    private final String id;
    private String year;
    private String name;
    private User author;
    private int highestPriceValueSold;

    public ArtworkClass(String id, User author, String year, String name){
        this.id = id;
        this.author = author;
        this.year = year;
        this.name = name;
        highestPriceValueSold = 0;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public User getAuthor() {
        return author;
    }

    @Override
    public String getYear() {
        return year;
    }

    @Override
    public int getPriceSold() {
        return highestPriceValueSold;
    }

    @Override
    public boolean updateHighestPriceSold(Bid bid) {
        if(highestPriceValueSold == 0 || highestPriceValueSold < bid.getValue()){
            highestPriceValueSold = bid.getValue();
            return true;
        }
        return false;
    }
}
