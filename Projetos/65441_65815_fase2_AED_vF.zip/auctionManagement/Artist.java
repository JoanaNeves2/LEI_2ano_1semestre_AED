package auctionManagement;

import dataStructures.Entry;
import dataStructures.Iterator;

/**
 * Artist public interface.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public interface Artist extends User{

    /**
     *
     * @return the artist name of the artist.
     */
    String getArtistName();

    /**
     *
     * @return true if artist doesn't have any artworks, false otherwise.
     */
    boolean isEmpty();

    /**
     *
     * @return true when the artist has artworks in auction, false otherwise
     */
    boolean hasArtworksInAuction();

    /**
     * @return an iterator of all the artist's artworks.
     */
    Iterator<Entry<String, Artwork>> getArtworks();
}
