package auctionManagement;

/**
 * Abstract class for the user. Resembles a user of the system.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
abstract class AbstractUserClass implements PrivateUser{

    /**
     * Serial Version UID
     */
    private static final long serialVersionUID = 0L;
    public static final int ZERO = 0;

    //Instance Variables
    protected final String login, name, email;
    protected final int age;
    protected int countBidsActive;

    /**
     * Constructs a new User.
     *
     * @param login the login of the user.
     * @param name the name of the user.
     * @param age the age of the user.
     * @param email the email of the user.
     */
    AbstractUserClass(String login, String name, int age, String email){
        this.login = login;
        this.name = name;
        this.age = age;
        this.email = email;
        this.countBidsActive = ZERO;
    }

    @Override
    public String getLogin(){
        return login;
    }

    @Override
    public String getName(){
        return name;
    }

    @Override
    public int getAge(){
        return age;
    }

    @Override
    public String getEmail(){
        return email;
    }

    @Override
    public boolean hasActiveBids(){
        return countBidsActive != ZERO;
    }

    @Override
    public void addBid(){
        countBidsActive++;
    }
    @Override
    public void removeBid(){
        countBidsActive--;
    }
}
