package auctionManagement;

/**
 * This class represents a user of type collector.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public class CollectorClass extends AbstractUserClass implements PrivateCollector{

    public CollectorClass(String login, String name, int age, String email){
        super(login, name, age, email);
    }

}
