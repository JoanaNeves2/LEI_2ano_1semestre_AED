package auctionManagement;

/**
 * Bid public interface.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public interface Bid {

    /**
     *
     * @return the value of the bid
     */
    int getValue();

    /**
     *
     * @return the user who made the bid.
     */
    User getBidder();
}
