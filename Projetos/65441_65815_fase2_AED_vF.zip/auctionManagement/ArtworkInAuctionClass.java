package auctionManagement;

import dataStructures.DoubleList;
import dataStructures.Iterator;

import java.io.Serial;

/**
 * This class represents an artwork when it is in an auction.
 * This class manages all the information about the bids that are made
 * to its artwork in its auction.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public class ArtworkInAuctionClass implements PrivateArtworkInAuction{

    /**
     * Serial Version UID
     */
    @Serial
    private static final long serialVersionUID = 0L;

    private final Artwork artwork;
    private final int minimumPrice;
    private Bid highestBid;
    private boolean sold;
    private DoubleList<Bid> bids;

    public ArtworkInAuctionClass(Artwork artwork, int minimumPrice){
        this.artwork = artwork;
        this.minimumPrice = minimumPrice;
        highestBid = null;
        sold = false;
        bids = new DoubleList<>();
    }

    @Override
    public Artwork getArtwork() {
        return artwork;
    }

    @Override
    public int getMinimumPrice() {
        return minimumPrice;
    }

    @Override
    public void addBid(Auction auction, Bid newBid) {
        bids.addLast(newBid);
        if(highestBid == null || newBid.getValue() > highestBid.getValue()) {
            highestBid = newBid;
        }
    }

    @Override
    public Bid getHighestBid() {
        return highestBid;
    }

    @Override
    public boolean isSold() {
        return sold;
    }

    @Override
    public Iterator<Bid> getBids() {
        return bids.iterator();
    }

    @Override
    public boolean hasBids() {
        return !bids.isEmpty();
    }

    @Override
    public void close() {
        //vender a obra se tiver propostas válidas
        if(hasBids()) {
            sold = true;
            ((PrivateArtwork) artwork).updateHighestPriceSold(highestBid);
        }

        //remover as bids de cada user
        Iterator<Bid> itBids = bids.iterator();

        while (itBids.hasNext()){
            ((PrivateUser) itBids.next().getBidder()).removeBid();
        }
    }


}
