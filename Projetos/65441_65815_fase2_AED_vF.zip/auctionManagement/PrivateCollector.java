package auctionManagement;

import java.io.Serializable;

/**
 * Collector private interface.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
interface PrivateCollector extends Collector, Serializable {

}
