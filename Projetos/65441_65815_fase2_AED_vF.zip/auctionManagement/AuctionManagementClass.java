package auctionManagement;

import dataStructures.*;
import exceptions.*;

/**
 * Auction management class that communicates with the Main.
 * Stores all the information regarding the users, the artworks
 * and the auctions.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public class AuctionManagementClass implements AuctionManagement{

    /**
     * Serial Version UID
     */
    private static final long serialVersionUID = 0L;
    public static final int MINIMUM_AGE = 18;

    //Dictionaries

    /**
     * Dictionary with all the users of the system.
     * Key the login of the user in lower case. (String)
     * Value the user. (User)
     */
    final Dictionary<String, User> users;

    /**
     * Dictionary with all the artworks of the system.
     * Key the id of the artwork in lower case. (String)
     * Value the artwork. (Artwork)
     */
    final Dictionary<String, Artwork> artworks;

    /**
     * Dictionary with all the auctions of the system.
     * Key the id of the auction in lower case. (String)
     * Value the auction. (Auction)
     */
    final Dictionary<String, Auction> auctions;

    /**
     * OrderedDictionary with all artworks that have already been sold for the ranking of the system.
     * Key the highest price sold of the artwork. (String)
     * Value an OrderedDictionary with all artworks that have already been sold of the system.
     * Key the name of the auction in lower case. (String)
     * Value the artwork. (Artwork)
     */
    private OrderedDictionary<Integer, OrderedDictionary<String, Artwork>> artworksRanking;

    public AuctionManagementClass(){
        this.users = new SepChainHashTable<>();
        this.artworks = new SepChainHashTable<>();
        this.auctions = new SepChainHashTable<>();
        this.artworksRanking = new AVLTreeWithComparator<>(new InverseIntegerComparator());
    }

    @Override
    public void addCollector(String login, String name, int age, String email)
            throws UserUnderageException, UserAlreadyExistsException {

        if(age < MINIMUM_AGE)
            throw new UserUnderageException();
        if(users.find(login.toLowerCase()) != null)
            throw new UserAlreadyExistsException();

        users.insert(login.toLowerCase(), new CollectorClass(login, name, age, email));
    }

    @Override
    public void addArtist(String login, String name, String artistName, int age, String email)
            throws UserUnderageException, UserAlreadyExistsException {

        if(age < MINIMUM_AGE)
            throw new UserUnderageException();
        if(users.find(login.toLowerCase()) != null)
            throw new UserAlreadyExistsException();

        users.insert(login.toLowerCase(), new ArtistClass(login, name, artistName, age, email));
    }

    @Override
    public void removeUser(String login)
            throws UserDoesntExistException, UserHasActiveBidsException, ArtistHasArtworkInAuctionException {

        User user = users.find(login.toLowerCase());
        if(user == null)
            throw new UserDoesntExistException();
        if(user.hasActiveBids())
            throw new UserHasActiveBidsException();
        if(user instanceof Artist && ((Artist) user).hasArtworksInAuction())
            throw new ArtistHasArtworkInAuctionException();

        if(user instanceof Artist) {
            //Removal of the artists artworks when it is removed
            Iterator<Entry<String, Artwork>> it = ((Artist) user).getArtworks();
            while (it.hasNext()) {
                Artwork nextArt = it.next().getValue();
                artworks.remove(nextArt.getId());
                int priceSold = nextArt.getPriceSold();
                if(priceSold != 0) {
                    OrderedDictionary<String, Artwork> sameValue = artworksRanking.find(priceSold);
                    sameValue.remove(nextArt.getName());
                }
            }
        }
        users.remove(login.toLowerCase());
    }

    @Override
    public void addWork(String artworkID, String authorLogin, String year, String name)
            throws ArtworkAlreadyExistsException, UserDoesntExistException, UserIsNotAnArtistException{

        if(artworks.find(artworkID.toLowerCase()) != null)
            throw new ArtworkAlreadyExistsException();

        User u = users.find(authorLogin.toLowerCase());
        Artwork newArtwork = new ArtworkClass(artworkID, u, year, name);

        if(u == null)
            throw new UserDoesntExistException();
        if(!(u instanceof Artist))
            throw new UserIsNotAnArtistException();
        ((PrivateArtist) u).addArtwork(newArtwork);
        artworks.insert(artworkID.toLowerCase(), newArtwork);
    }

    @Override
    public User getUser(String login)
            throws UserDoesntExistException {

        User u = users.find(login.toLowerCase());
        if(u == null)
            throw new UserDoesntExistException();
        return u;
    }

    @Override
    public Artist getArtist(String login)
            throws UserDoesntExistException, UserIsNotAnArtistException {

        User u = getUser(login);
        if(!(u instanceof Artist))
            throw new UserIsNotAnArtistException();

        return (Artist) u;
    }

    @Override
    public Artwork getArtwork(String id)
            throws ArtworkDoesntExistException {

        Artwork a = artworks.find(id.toLowerCase());
        if(a == null)
            throw new ArtworkDoesntExistException();
        return a;
    }

    @Override
    public void createAuction(String id)
            throws AuctionAlreadyExistsException {

        if(auctions.find(id.toLowerCase()) != null)
            throw new AuctionAlreadyExistsException();

        auctions.insert(id.toLowerCase(), new AuctionClass(id));
    }

    @Override
    public void addArtworkToAuction(String auctionId, String artworkId, int minimumBid)
            throws AuctionDoesntExistException, ArtworkDoesntExistException {

        Auction auction = auctions.find(auctionId.toLowerCase());
        if(auction == null)
            throw new AuctionDoesntExistException();

        Artwork artwork = artworks.find(artworkId);

        if(artwork == null)
            throw new ArtworkDoesntExistException();

        ((PrivateAuction) auction).addArtwork(artwork, minimumBid);
    }

    @Override
    public void bid(String auctionId, String artworkId, String login, int value)
            throws UserDoesntExistException, AuctionDoesntExistException, ArtworkDoesntExistInAuctionException, BidBelowMinimumValueException {

        User user = users.find(login.toLowerCase());
        if(user == null)
            throw new UserDoesntExistException();

        Auction auction = auctions.find(auctionId.toLowerCase());
        if(auction == null)
            throw new AuctionDoesntExistException();

        Artwork artwork = artworks.find(artworkId.toLowerCase());
        if(artwork == null || !auction.isArtworkInAuction(artwork))
            throw new ArtworkDoesntExistInAuctionException();

        if(value < auction.getArtworkMinimumPrice(artwork))
            throw new BidBelowMinimumValueException();

        ((PrivateAuction) auction).addBid(value, user, artwork);
    }

    @Override
    public Iterator<ArtworkInAuction> closeAuction(String auctionId)
            throws AuctionDoesntExistException {

        Auction auction = auctions.remove(auctionId.toLowerCase());
        if(auction == null)
            throw new AuctionDoesntExistException();

        ((PrivateAuction) auction).close(artworksRanking);

        return auction.getArtworkIterator();
    }

    @Override
    public Iterator<ArtworkInAuction> listAuctionWorks(String idAuction) throws AuctionDoesntExistException, AuctionEmptyException {
        Auction auction = auctions.find(idAuction);
        if(auction == null)
            throw new AuctionDoesntExistException();
        if(auction.isEmpty())
            throw new AuctionEmptyException();
        return auction.getArtworkIterator();
    }

    @Override
    public Iterator<Bid> listBidsWork(String idAuction, String idArtwork) throws AuctionDoesntExistException, ArtworkDoesntExistInAuctionException, ArtworkWithNoBidsException {
        Auction auction = auctions.find(idAuction);
        if(auction == null)
            throw new AuctionDoesntExistException();

        ArtworkInAuction artwork = auction.getArtworkById(idArtwork);
        if(artwork == null)
            throw new ArtworkDoesntExistInAuctionException();

        if(!artwork.hasBids())
            throw new ArtworkWithNoBidsException();

        return artwork.getBids();
    }

    @Override
    public Iterator<Entry<String, Artwork>> listArtistWorks(String login) throws UserIsNotAnArtistException, ArtistWithoutArtworksException, UserDoesntExistException {
        User user = users.find(login);
        if(user == null)
            throw new UserDoesntExistException();

        if (user instanceof Artist){
            if(((Artist) user).isEmpty())
                throw new ArtistWithoutArtworksException();
            return ((Artist) user).getArtworks();
        }else
            throw new UserIsNotAnArtistException();
    }

    @Override

    public Iterator<Entry<Integer, OrderedDictionary<String, Artwork>>> listArtworksByValue() throws DoesntExistAnyArtworksSoldException {
        if(artworksRanking.isEmpty())
            throw new DoesntExistAnyArtworksSoldException();
        return artworksRanking.iterator();
    }

}
