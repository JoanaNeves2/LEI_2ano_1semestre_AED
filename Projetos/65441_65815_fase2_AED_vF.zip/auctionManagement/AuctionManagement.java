package auctionManagement;

import dataStructures.Entry;
import dataStructures.Iterator;
import dataStructures.OrderedDictionary;
import exceptions.*;

import java.io.Serializable;

/**
 * Auction management interface.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public interface AuctionManagement extends Serializable {

    /**
     * Adds a new Collector user to the system.
     *
     * @param login the identifier/login of the collector
     * @param name the name of the collector
     * @param age the age of the collector
     * @param email the email of the collector
     * @throws UserUnderageException if the collector is underage
     * @throws UserAlreadyExistsException if the user already exists in the system
     */
    void addCollector(String login, String name, int age, String email) throws UserUnderageException, UserAlreadyExistsException;

    /**
     * Adds a new Artist user to the system.
     *
     * @param login the identifier/login of the artist
     * @param name the name of the artist
     * @param artistName the artist name of the artist
     * @param age the age of the artist
     * @param email the email of the artist
     * @throws UserUnderageException if the artist is underage
     * @throws UserAlreadyExistsException if the user already exists in the system
     */
    void addArtist(String login, String name, String artistName, int age, String email) throws UserUnderageException, UserAlreadyExistsException;

    /**
     * Removes a user from the system.
     *
     * @param login is the identifier/login of the user
     * @throws UserDoesntExistException if the user doesn't exist in the system
     * @throws UserHasActiveBidsException if the user has active bids
     * @throws ArtistHasArtworkInAuctionException if the user is an artist and if he has any of his artwork in any auction
     */
    void removeUser(String login) throws UserDoesntExistException, UserHasActiveBidsException, ArtistHasArtworkInAuctionException;

    /**
     * Adds a new artwork to the system.
     *
     * @param artworkID the identifier of the artwork
     * @param authorLogin the identifier/login of the user
     * @param year the year in which the artwork was created
     * @param name the name of the artwork
     * @throws ArtworkAlreadyExistsException if the artwork already exists in the system
     * @throws UserDoesntExistException if the user doesn't exist in the system
     * @throws UserIsNotAnArtistException if the user that corresponds to the given login isn't an artist
     */
    void addWork(String artworkID, String authorLogin, String year, String name) throws ArtworkAlreadyExistsException, UserDoesntExistException, UserIsNotAnArtistException;

    /**
     * Returns the specified user.
     *
     * @param login the identifier/login of the user we are looking for
     * @return the specified user
     * @throws UserDoesntExistException if the user doesn't exist in the system
     */
    User getUser(String login) throws UserDoesntExistException;

    /**
     * Returns the specified artist.
     *
     * @param login the identifier/login of the artist we are looking for
     * @return the specified artist
     * @throws UserDoesntExistException if the user doesn't exist in the system
     * @throws UserIsNotAnArtistException if the user that corresponds to the given login isn't an artist
     */
    Artist getArtist(String login) throws UserDoesntExistException, UserIsNotAnArtistException;

    /**
     * Returns the specified artwork.
     *
     * @param id the identifier of the artwork we can look for information
     * @return the specified artwork
     * @throws ArtworkDoesntExistException if the artwork doesn't exist into the system
     */
    Artwork getArtwork(String id) throws ArtworkDoesntExistException;

    /**
     * Creates a new auction in the system.
     *
     * @param id is the identifier of the auction we want to create
     * @throws AuctionAlreadyExistsException if the auction already exists in the system
     */
    void createAuction(String id) throws AuctionAlreadyExistsException;

    /**
     * Adds an artwork to an auction, with a minimum bid value.
     *
     * @param auctionId the identifier of the auction which we want to add an artwork to
     * @param artworkId the identifier of the artwork we want to add
     * @param minimumBid the minimum value at which the artwork can be sold in the auction
     * @throws AuctionDoesntExistException if the auction doesn't exist in the system
     * @throws ArtworkDoesntExistException if the artwork doesn't exist in the system
     */
    void addArtworkToAuction(String auctionId, String artworkId, int minimumBid) throws AuctionDoesntExistException, ArtworkDoesntExistException;

    /**
     * Adds a new bid to a specific artwork in a specific auction.
     *
     * @param auctionId the identifier of the auction that has the artwork
     * @param artworkId the identifier of the artwork
     * @param login the identifier of the user who made the bid
     * @param value the value of the bid
     * @throws UserDoesntExistException if the user doesn't exist in the system
     * @throws AuctionDoesntExistException if the auction doesn't exist in the system
     * @throws ArtworkDoesntExistInAuctionException if the artwork doesn't exist in the specified auction
     * @throws BidBelowMinimumValueException if the value is below the minimum value of the artwork in this auction
     */
    void bid(String auctionId, String artworkId, String login, int value) throws UserDoesntExistException, AuctionDoesntExistException, ArtworkDoesntExistInAuctionException, BidBelowMinimumValueException;

    /**
     * Closes a specific auction, and returns an iterator of all the artworks that were being sold in it.
     *
     * @param auctionId the identifier of the auction we want to close
     * @return an iterator that goes through all the artwork that were in the auction
     * @throws AuctionDoesntExistException if the auction doesn't exist in the system
     */
    Iterator<ArtworkInAuction> closeAuction(String auctionId) throws AuctionDoesntExistException;

    /**
     * 
     * @param idAuction the identifier of the auction we want to list with all artworks
     * @return an iterator that goes through all the artwork that were in the auction
     * @throws AuctionDoesntExistException
     * @throws AuctionEmptyException
     */
    Iterator<ArtworkInAuction> listAuctionWorks(String idAuction) throws AuctionDoesntExistException, AuctionEmptyException;

    /**
     * 
     * @param idAuction the identifier of the auction we want to list with all bids by this artworks
     * @param idArtwork the identifier of the artwork
     * @return an iterator that goes through all the bids that were in the artwork
     * @throws AuctionDoesntExistException
     * @throws ArtworkDoesntExistInAuctionException
     * @throws ArtworkWithNoBidsException
     */
    Iterator<Bid> listBidsWork(String idAuction, String idArtwork) throws AuctionDoesntExistException, ArtworkDoesntExistInAuctionException, ArtworkWithNoBidsException;

    /**
     *
     * @param login the identifier of the user who made the bid
     * @return an iterator that goes through all the Entry with the artwork's names like the key and with artwork like the value
     * @throws UserIsNotAnArtistException
     * @throws ArtistWithoutArtworksException
     * @throws UserDoesntExistException
     */
    Iterator<Entry<String, Artwork>> listArtistWorks(String login) throws UserIsNotAnArtistException, ArtistWithoutArtworksException, UserDoesntExistException;

    /**
     * @return an iterator that goes through all the Entry with the artwork's highest price sold like the key and with an orderedDictionary<String, Artwork>> like the value
     * @throws DoesntExistAnyArtworksSoldException
     */
    Iterator<Entry<Integer, OrderedDictionary<String, Artwork>>> listArtworksByValue() throws DoesntExistAnyArtworksSoldException;
}
