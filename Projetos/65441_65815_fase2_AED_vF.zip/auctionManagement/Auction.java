package auctionManagement;

import dataStructures.Iterator;

/**
 * Auction public interface.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public interface Auction {

    /**
     *
     * @return get identifier of the auction
     */
    String getId();

    /**
     *
     * @param artwork is the artwork we want to check whether it's in the auction
     * @return true if the artwork is in this auction, false otherwise
     */
    boolean isArtworkInAuction(Artwork artwork);

    /**
     *
     * @param artwork is the artwork from which we want to know the minimum price at which it can be sold in this auction
     * @return the minimum price at which the artwork can be sold in this auction
     * @pre: isArtworkInAuction(Artwork artwork)
     */
    int getArtworkMinimumPrice(Artwork artwork);

    /**
     *
     * @return an iterator that goes through all the artworks in this auction
     */
    Iterator<ArtworkInAuction> getArtworkIterator();

    /**
     *
     * @return true if the auction doesn't have any artwork
     */
    boolean isEmpty();

    /**
     *
     * @param idArtwork is the identifier of the artwork
     * @return an ArtworkInAuction with this identifier (idArtwork)
     */
    ArtworkInAuction getArtworkById(String idArtwork);
}
