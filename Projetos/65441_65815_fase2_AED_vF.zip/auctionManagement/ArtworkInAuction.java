package auctionManagement;

import dataStructures.Iterator;

public interface ArtworkInAuction {

    /**
     *
     * @return the artwork
     */
    Artwork getArtwork();

    /**
     *
     * @return the lowest price at which this artwork can be sold in this auction
     */
    int getMinimumPrice();

    /**
     *
     * @return the highest bid this artwork has received in its auction.
     */
    Bid getHighestBid();

    /**
     *
     * @return true if the artwork has been sold, false otherwise.
     */
    boolean isSold();

    /**
     *
     * @return an iterator of all bids in this auction.
     */
    Iterator<Bid> getBids();

    /**
     *
     * @return true if the artwork has any bid in this auction, false otherwise.
     */
    boolean hasBids();
}
