package auctionManagement;

import dataStructures.*;

import java.io.Serial;

/**
 * This class represents an auction.
 * This class manages all the information about each auction.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public class AuctionClass implements PrivateAuction{

    /**
     * Serial Version UID
     */
    @Serial
    private static final long serialVersionUID = 0L;

    //Instance Variables
    private final String id;
    private final Dictionary<String, ArtworkInAuction> artworksInAuctionDictionary;
    private final DoubleList<ArtworkInAuction> artworksInAuctionList;

    public AuctionClass(String id){
        this.id = id;
        this.artworksInAuctionList = new DoubleList<>();
        this.artworksInAuctionDictionary = new SepChainHashTable<>();
    }

    @Override
    public void addArtwork(Artwork artwork, int minimumPrice) {
        if(artworksInAuctionDictionary.find(artwork.getId().toLowerCase()) == null) {
            ArtworkInAuction art = new ArtworkInAuctionClass(artwork, minimumPrice);
            artworksInAuctionDictionary.insert(artwork.getId().toLowerCase(), art);
            artworksInAuctionList.addLast(art);
            ((PrivateArtist) artwork.getAuthor()).addArtworkInAuction();
        }
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public boolean isArtworkInAuction(Artwork artwork) {
        return artworksInAuctionDictionary.find(artwork.getId().toLowerCase()) != null;
    }

    @Override
    public int getArtworkMinimumPrice(Artwork artwork) {
        return artworksInAuctionDictionary.find(artwork.getId().toLowerCase()).getMinimumPrice();
    }

    @Override
    public void addBid(int value, User bidder, Artwork artWork) {
        Bid newBid = new BidClass(value, bidder, this);
        ArtworkInAuction artwork = artworksInAuctionDictionary.find(artWork.getId().toLowerCase());
        ((PrivateArtworkInAuction) artwork).addBid(this, newBid);
        ((PrivateUser) bidder).addBid();
    }

    @Override
    public Iterator<ArtworkInAuction> getArtworkIterator() {
        return artworksInAuctionList.iterator();
    }

    @Override
    public boolean isEmpty() {
        return artworksInAuctionList.isEmpty();
    }

    @Override
    public ArtworkInAuction getArtworkById(String idArtwork) {
        return artworksInAuctionDictionary.find(idArtwork);
    }

    @Override
    public void close(OrderedDictionary<Integer, OrderedDictionary<String, Artwork>> artworksRanking) {
        Iterator<ArtworkInAuction> it = artworksInAuctionList.iterator();
        while (it.hasNext()){
            ArtworkInAuction art = it.next();
            Bid highestBid = art.getHighestBid();
            Artwork artwork = art.getArtwork();
            int soldPrice = artwork.getPriceSold();

            //If it has a bid it can be sold in this auction
            if(highestBid != null) {
                boolean isUpload = ((PrivateArtwork) artwork).updateHighestPriceSold(highestBid);
                if (isUpload) {
                    //If it has already been sold in another auction and the highest price has been updated
                    if (soldPrice != 0) {
                        if (artworksRanking.find(soldPrice) != null) {
                            artworksRanking.find(soldPrice).remove(artwork.getName());
                        }
                    }

                    if (artworksRanking.find(highestBid.getValue()) == null)
                        artworksRanking.insert(highestBid.getValue(), new AVLTree<>());

                    //Adds the artwork to the ranking
                    artworksRanking.find(highestBid.getValue()).insert(artwork.getName(), (PrivateArtwork) artwork);
                }
                ((PrivateArtworkInAuction) art).close();
            }

            ((PrivateArtist) artwork.getAuthor()).removeArtworkInAuction();
        }
    }
}
