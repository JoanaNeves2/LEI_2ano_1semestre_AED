package auctionManagement;

/**
 * Artwork public interface.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public interface Artwork {

    /**
     *
     * @return the identifier of the artwork
     */
    String getId();

    /**
     *
     * @return the name of the artwork
     */
    String getName();

    /**
     *
     * @return the user who created the artwork
     */
    User getAuthor();

    /**
     *
     * @return the year in which the artwork was created
     */
    String getYear();

    /**
     *
     * @return the highest price at which this artwork was sold
     */
    int getPriceSold();
}
