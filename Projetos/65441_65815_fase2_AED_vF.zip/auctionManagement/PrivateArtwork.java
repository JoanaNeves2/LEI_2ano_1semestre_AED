package auctionManagement;

import java.io.Serializable;

interface PrivateArtwork extends Artwork, Serializable {

    /**
     * checks if the value of the bid is higher than the actual highest bid and if so, uploads the highest
     * bid for the current artwork and returns true, otherwise returns false
     *
     * @param bid the actual highest Bid for this artwork
     * @return true if the highestBid was uploaded
     */
    boolean updateHighestPriceSold(Bid bid);
}
