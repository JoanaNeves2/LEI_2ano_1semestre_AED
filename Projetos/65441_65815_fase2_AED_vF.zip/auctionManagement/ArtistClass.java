package auctionManagement;

import dataStructures.*;

/**
 * This class represents a user of type artist.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public class ArtistClass extends AbstractUserClass implements PrivateArtist{

    /**
     * Serial Version UID
     */
    private static final long serialVersionUID = 0L;

    //Instance Variables

    private final String artistName;
    protected int hasArtworksInAuction;
    private OrderedDictionary<String, Artwork> artworks;

    public ArtistClass(String login, String name, String artistName, int age, String email){
        super(login, name, age, email);
        this.artistName = artistName;
        this.artworks = new BinarySearchTree<>();
        this.hasArtworksInAuction = ZERO;
    }

    @Override
    public String getArtistName() {
        return artistName;
    }

    @Override
    public void addArtwork(Artwork artwork) {
        artworks.insert(artwork.getName(), artwork);
    }

    @Override
    public void addArtworkInAuction() {
        hasArtworksInAuction++;
    }

    @Override
    public void removeArtworkInAuction() {
        hasArtworksInAuction--;
    }

    @Override
    public boolean hasArtworksInAuction() {
        return hasArtworksInAuction != ZERO;
    }

    @Override
    public boolean isEmpty() {
        return artworks.isEmpty();
    }

    @Override
    public Iterator<Entry<String, Artwork>> getArtworks() {
        return artworks.iterator();
    }
}
