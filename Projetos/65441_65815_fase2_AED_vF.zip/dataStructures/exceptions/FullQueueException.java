package dataStructures.exceptions;

public class FullQueueException extends RuntimeException{                                     
    static final long serialVersionUID = 0L;
}
