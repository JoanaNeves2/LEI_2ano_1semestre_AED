package dataStructures;

public interface Comparator<E> {

    int compare(E element1, E element2);
}
