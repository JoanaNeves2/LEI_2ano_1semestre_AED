package dataStructures;

public class BSTWithComparator<K extends Comparable<K>, V> extends BinarySearchTree<K,V>{

    /**
     * Serial Version UID
     */
    private static final long serialVersionUID = 0L;
    private Comparator<K> comparator;

    public BSTWithComparator(Comparator<K> newComparator){
        super();
        this.comparator = newComparator;
    }

    @Override
    protected BSTNode<K,V> findNode( BSTNode<K,V> node, K key )
    {
        if ( node == null )
            return null;
        else
        {
            int compResult = comparator.compare(key,node.getKey());
            if ( compResult == 0 )
                return node;
            else if ( compResult < 0 )
                return this.findNode(node.getLeft(), key);
            else
                return this.findNode(node.getRight(), key);
        }
    }

    @Override
    protected BSTNode<K,V> findNode( K key, PathStep<K,V> lastStep ){
        BSTNode<K,V> node = root;
        while ( node != null )
        {
            int compResult = comparator.compare(key,node.getKey());
            if ( compResult == 0 )
                return node;
            else if ( compResult < 0 )
            {
                lastStep.set(node, true);
                node = node.getLeft();
            }
            else
            {
                lastStep.set(node, false);
                node = node.getRight();
            }
        }
        return null;
    }
}
