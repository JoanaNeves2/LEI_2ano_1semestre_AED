package dataStructures;

import java.io.Serializable;

/**
 * Inverse Integer Comparator
 *
 * This comparator is used to order keys in descending order.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public class InverseIntegerComparator implements Comparator<Integer>, Serializable {

    /**
     * Serial Version UID
     */
    private static final long serialVersionUID = 0L;
    @Override
    public int compare(Integer key1, Integer key2) {
        return key2-key1;
    }
}
