package dataStructures;

public class Main {
    public static void main(String[] args) {
        Dictionary<String, Integer> people = new SepChainHashTable<>(100);
        System.out.println(people.insert("r", 20));
        System.out.println(people.insert("João", 22));
        System.out.println(people.insert("João", 20));
        System.out.println(people.insert("André", 17));
        System.out.println(people.insert("André", 19));
        System.out.println(people.insert("André", 17));

        System.out.println("///-----///");
        Iterator<Entry<String, Integer>> it = people.iterator();

        while(it.hasNext()){
            System.out.println(it.next().getKey());
        }

    }
}
