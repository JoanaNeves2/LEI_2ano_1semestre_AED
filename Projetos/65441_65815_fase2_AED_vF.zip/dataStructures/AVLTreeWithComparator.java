package dataStructures;

/**
 * AVL inverse tree implementation
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public class AVLTreeWithComparator<K extends Comparable<K>, V>
        extends AVLTree<K,V>
{

    /**
     * Serial Version UID
     */
    private static final long serialVersionUID = 0L;
    private final Comparator<K> comparator;

    public AVLTreeWithComparator(Comparator<K> newComparator){
        super();
        this.comparator = newComparator;
    }

    @Override
    protected BSTNode<K,V> findNode( BSTNode<K,V> node, K key )
    {
        if ( node == null )
            return null;
        else
        {
            int compResult = comparator.compare(key,node.getKey());
            if ( compResult == 0 )
                return node;
            else if ( compResult < 0 )
                return this.findNode(node.getLeft(), key);
            else
                return this.findNode(node.getRight(), key);
        }
    }

    @Override
    protected BSTNode<K,V> findNode( K key, Stack<PathStep<K,V>> path )
    {
        path.push( new PathStep<K,V>(null, false) );
        BSTNode<K,V> node = root;
        while ( node != null )
        {
            int compResult = comparator.compare(key,node.getKey());
            if ( compResult == 0 )
                return node;
            else if ( compResult < 0 )
            {
                path.push( new PathStep<K,V>(node, true) );
                node = node.getLeft();
            }
            else
            {
                path.push( new PathStep<K,V>(node, false) );
                node = node.getRight();
            }
        }
        return null;
    }
}
