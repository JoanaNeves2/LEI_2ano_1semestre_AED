import auctionManagement.*;
import dataStructures.Entry;
import dataStructures.OrderedDictionary;
import exceptions.*;
import dataStructures.Iterator;
import enums.*;

import java.io.*;
import java.util.Scanner;

/**
 * Main class for the Art Auction project.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public class Main {

    //Name of the .dat file where the state of the program will be stored.
    private static final String DAT_FILE = "storeddata.dat";

    /**
     * main program. Invokes the command interpreter.
     *
     * @param args - Arguments for execution of the program. Not used on this program.
     */
    public static void main(String[] args) {
        Main.commandProcessor();
    }

    /**
     * Command interpreter.
     */
    private static void commandProcessor() {

        AuctionManagement am = load();

        Scanner in = new Scanner(System.in);

        Command c = getCommand(in);

        while (!c.equals(Command.QUIT)) {
            assert am != null;
            switch (c) {
                case ADDUSER:
                    addUser(in, am);
                    break;
                case ADDARTIST:
                    addArtist(in, am);
                    break;
                case REMOVEUSER:
                    removeUser(in, am);
                    break;
                case ADDWORK:
                    addWork(in, am);
                    break;
                case INFOUSER:
                    infoUser(in, am);
                    break;
                case INFOARTIST:
                    infoArtist(in, am);
                    break;
                case INFOWORK:
                    infoWork(in, am);
                    break;
                case CREATEAUCTION:
                    createAuction(in, am);
                    break;
                case ADDWORKAUCTION:
                    addWorkAuction(in, am);
                    break;
                case BID:
                    bid(in, am);
                    break;
                case CLOSEAUCTION:
                    closeAuction(in, am);
                    break;
                case LISTAUCTIONWORKS:
                    listAuctionWorks(in, am);
                    break;
                case LISTARTISTWORKS:
                    listArtistWorks(in, am);
                    break;
                case LISTBIDSWORK:
                    listBidWorks(in, am);
                    break;
                case LISTWORKSBYVALUE:
                    listArtworksByValue(am);
            }
            c = getCommand(in);
            System.out.println();
        }
        quit();
        save(am);
        in.close();
    }

    /**
     * Adds a new collector to the system.
     *
     * @param in Scanner that reads the user's inputs
     * @param am Object of the AuctionManagement Class
     */
    private static void addUser(Scanner in, AuctionManagement am) {
        String login = in.next();
        String name = in.nextLine().trim();
        int age = in.nextInt();
        String email = in.next();
        in.nextLine();

        try {
            am.addCollector(login, name, age, email);
            System.out.print(Output.REGISTER_USER_SUCCESS.getOutput());
        } catch (UserUnderageException e) {
            System.out.print(Output.USER_UNDERAGE.getOutput());
        } catch (UserAlreadyExistsException e) {
            System.out.print(Output.USER_ALREADY_EXISTS.getOutput());
        }
    }

    /**
     * Adds a new artist to the system.
     *
     * @param in Scanner that reads the user's inputs
     * @param am Object of the AuctionManagement Class
     */
    private static void addArtist(Scanner in, AuctionManagement am) {
        String login = in.next();
        String name = in.nextLine().trim();
        String artistName = in.nextLine();
        int age = in.nextInt();
        String email = in.next();
        in.nextLine();

        try {
            am.addArtist(login, name, artistName, age, email);
            System.out.print(Output.REGISTER_ARTIST_SUCCESS.getOutput());
        } catch (UserUnderageException e) {
            System.out.print(Output.USER_UNDERAGE.getOutput());
        } catch (UserAlreadyExistsException e) {
            System.out.print(Output.USER_ALREADY_EXISTS.getOutput());
        }
    }

    /**
     * Removes a certain user from the system
     *
     * @param in Scanner that reads the user's inputs
     * @param am Object of the AuctionManagement Class
     */
    private static void removeUser(Scanner in, AuctionManagement am) {
        String login = in.next();
        in.nextLine();

        try {
            am.removeUser(login);
            System.out.print(Output.REMOVE_USER.getOutput());
        } catch (UserDoesntExistException e) {
            System.out.print(Output.USER_DOESNT_EXIST.getOutput());
        } catch (UserHasActiveBidsException e) {
            System.out.print(Output.USER_HAS_ACTIVE_BIDS.getOutput());
        } catch (ArtistHasArtworkInAuctionException e) {
            System.out.println(Output.ARTIST_HAS_ARTWORK_IN_AUCTION.getOutput());
        }
    }

    /**
     * Adds a new artwork to the system.
     *
     * @param in Scanner that reads the user's inputs
     * @param am Object of the AuctionManagement Class
     */
    private static void addWork(Scanner in, AuctionManagement am) {
        String idArtwork = in.next().trim();
        String loginAuthor = in.next();
        String year = in.next();
        String name = in.nextLine().trim();

        try {
            am.addWork(idArtwork, loginAuthor, year, name);
            System.out.print(Output.REGISTER_ARTWORK_SUCCESS.getOutput());
        } catch (ArtworkAlreadyExistsException e) {
            System.out.print(Output.ARTWORK_ALREADY_EXISTS.getOutput());
        } catch (UserDoesntExistException e) {
            System.out.print(Output.USER_DOESNT_EXIST.getOutput());
        } catch (UserIsNotAnArtistException e) {
            System.out.print(Output.ARTIST_DOESNT_EXIST.getOutput());
        }
    }

    /**
     * Lists a collector's information.
     *
     * @param in Scanner that reads the user's inputs
     * @param am Object of the AuctionManagement Class
     */
    private static void infoUser(Scanner in, AuctionManagement am) {
        String login = in.next().trim();
        in.nextLine();

        try {
            User user = am.getUser(login);
            System.out.printf(Output.INFO_USER.getOutput(), user.getLogin(), user.getName(), user.getAge(),
                    user.getEmail());
        } catch (UserDoesntExistException e) {
            System.out.print(Output.USER_DOESNT_EXIST.getOutput());
        }
    }

    /**
     * Lists an artist's information.
     *
     * @param in Scanner that reads the user's inputs
     * @param am Object of the AuctionManagement Class
     */
    private static void infoArtist(Scanner in, AuctionManagement am) {
        String login = in.next().trim();
        in.nextLine();

        try {
            Artist artist = am.getArtist(login);
            System.out.printf(Output.INFO_ARTIST.getOutput(),artist.getLogin().trim(), artist.getName(),
                    artist.getArtistName(), artist.getAge(), artist.getEmail());
        } catch (UserDoesntExistException e) {
            System.out.print(Output.USER_DOESNT_EXIST.getOutput());
        } catch (UserIsNotAnArtistException e) {
            System.out.print(Output.ARTIST_DOESNT_EXIST.getOutput());
        }
    }

    /**
     * Lists an artwork's information.
     *
     * @param in Scanner that reads the user's inputs
     * @param am Object of the AuctionManagement Class
     */
    private static void infoWork(Scanner in, AuctionManagement am) {
        String idArtwork = in.next().trim();
        in.nextLine();

        try {
            Artwork artWork = am.getArtwork(idArtwork);
            System.out.printf(Output.INFO_WORK.getOutput(), artWork.getId(), artWork.getName(), artWork.getYear(), artWork.getPriceSold(),
                    artWork.getAuthor().getLogin(), artWork.getAuthor().getName());
        } catch (ArtworkDoesntExistException e) {
            System.out.print(Output.ARTWORK_DOESNT_EXIST.getOutput());
        }
    }

    /**
     * Adds a new auction to the system.
     *
     * @param in Scanner that reads the user's inputs
     * @param am Object of the AuctionManagement Class
     */
    private static void createAuction(Scanner in, AuctionManagement am) {
        String auctionID = in.next();
        in.nextLine();

        try {
            am.createAuction(auctionID);
            System.out.print(Output.REGISTER_AUCTION_SUCCESS.getOutput());
        } catch (AuctionAlreadyExistsException e) {
            System.out.print(Output.AUCTION_ALREADY_EXISTS.getOutput());
        }
    }

    /**
     * Adds an artwork to an auction
     *
     * @param in Scanner that reads the user's inputs
     * @param am Object of the AuctionManagement Class
     */
    private static void addWorkAuction(Scanner in, AuctionManagement am) {
        String auctionId = in.next();
        String artworkId = in.next();
        int minimumBid = in.nextInt();
        in.nextLine();

        try {
            am.addArtworkToAuction(auctionId, artworkId, minimumBid);
            System.out.print(Output.ADD_ARTWORK_TO_AUCTION_SUCCESS.getOutput());
        } catch (AuctionDoesntExistException e) {
            System.out.print(Output.AUCTION_DOESNT_EXIST.getOutput());
        } catch (ArtworkDoesntExistException e) {
            System.out.print(Output.ARTWORK_DOESNT_EXIST.getOutput());
        }
    }

    /**
     * Adds a new bid to an artwork of a specific auction.
     *
     * @param in Scanner that reads the user's inputs
     * @param am Object of the AuctionManagement Class
     */
    private static void bid(Scanner in, AuctionManagement am) {
        String auctionId = in.next();
        String artworkId = in.next();
        String login = in.next();
        int value = in.nextInt();
        in.nextLine();

        try {
            am.bid(auctionId, artworkId, login, value);
            System.out.print(Output.BID.getOutput());
        } catch (UserDoesntExistException e) {
            System.out.print(Output.USER_DOESNT_EXIST.getOutput());
        } catch (AuctionDoesntExistException e) {
            System.out.print(Output.AUCTION_DOESNT_EXIST.getOutput());
        } catch (ArtworkDoesntExistInAuctionException e) {
            System.out.print(Output.ARTWORK_DOESNT_EXIST_IN_AUCTION.getOutput());
        } catch (BidBelowMinimumValueException e) {
            System.out.print(Output.BID_BELOW_MINIMUM_VALUE.getOutput());
        }
    }

    /**
     * Closes an auction.
     *
     * @param in Scanner that reads the user's inputs
     * @param am Object of the AuctionManagement Class
     */
    private static void closeAuction(Scanner in, AuctionManagement am) {
        String auctionId = in.next();

        try {
            Iterator<ArtworkInAuction> it = am.closeAuction(auctionId);
            System.out.print(Output.CLOSE_AUCTION.getOutput());
            while (it.hasNext()) {
                ArtworkInAuction nextInAuction = it.next();
                Bid nextBid = nextInAuction.getHighestBid();
                Artwork next = nextInAuction.getArtwork();

                if (nextInAuction.isSold()) {
                    User buyer = nextBid.getBidder();
                    System.out.printf(Output.CLOSE_AUCTION_OUTPUT1.getOutput(),
                            next.getId(), next.getName(), buyer.getLogin(), buyer.getName(), nextBid.getValue());
                }
                else
                    System.out.printf(Output.CLOSE_AUCTION_OUTPUT2.getOutput(),
                            next.getId(), next.getName());
            }
            if(!it.hasNext())
                System.out.println();
        } catch (AuctionDoesntExistException e) {
            System.out.print(Output.AUCTION_DOESNT_EXIST.getOutput());
        }
    }

    /**
     * Lists the information of all artworks in a specific auction.
     *
     * @param in Scanner that reads the user's inputs
     * @param am Object of the AuctionManagement Class
     */
    private static void listAuctionWorks(Scanner in, AuctionManagement am) {
        String idAuction = in.next();
        in.nextLine();

        try{
            Iterator<ArtworkInAuction> it = am.listAuctionWorks(idAuction);
            System.out.println();
            while(it.hasNext()){
                ArtworkInAuction nextInClass = it.next();
                Artwork next = nextInClass.getArtwork();
                System.out.printf(Output.LIST_AUCTION_ARTWORKS.getOutput(), next.getId(), next.getName(), next.getYear(),
                        next.getPriceSold(), next.getAuthor().getLogin(), next.getAuthor().getName());
            }
        }catch (AuctionDoesntExistException e){
            System.out.print(Output.AUCTION_DOESNT_EXIST.getOutput());
        }catch (AuctionEmptyException e){
            System.out.print(Output.AUCTION_HAS_NO_ARTWORKS.getOutput());
        }
    }

    /**
     * Lists the information of all artworks of a specific artist.
     *
     * @param in Scanner that reads the user's inputs
     * @param am Object of the AuctionManagement Class
     */
    private static void listArtistWorks(Scanner in, AuctionManagement am) {
        String login = in.next();
        in.nextLine();

        try{
            Iterator<Entry<String, Artwork>> it = am.listArtistWorks(login);
            System.out.println();
            while (it.hasNext()){
                Entry<String, Artwork> next = it.next();
                Artwork art = next.getValue();
                System.out.printf(Output.ARTIST_ARTWORK.getOutput(),art.getId(),next.getKey(),art.getYear(),art.getPriceSold());
            }
        }catch (UserDoesntExistException e){
            System.out.print(Output.USER_DOESNT_EXIST.getOutput());
        }catch (UserIsNotAnArtistException e){
            System.out.print(Output.ARTIST_DOESNT_EXIST.getOutput());
        }catch (ArtistWithoutArtworksException e){
            System.out.print(Output.ARTIST_WITHOUT_ARTWORKS.getOutput());
        }
    }

    /**
     * Lists the information of all bids of a specific artwork.
     *
     * @param in Scanner that reads the user's inputs
     * @param am Object of the AuctionManagement Class
     */
    private static void listBidWorks(Scanner in, AuctionManagement am) {
        String idAuction = in.next();
        String idArtwork = in.next();
        in.nextLine();

        try{
            Iterator<Bid> it = am.listBidsWork(idAuction,idArtwork);
            while(it.hasNext()){
                Bid next = it.next();
                System.out.printf(Output.LIST_ARTWORK_BIDS.getOutput(),
                        next.getBidder().getLogin(),next.getBidder().getName(),next.getValue());
            }

            System.out.println();
        }catch (AuctionDoesntExistException e){
            System.out.print(Output.AUCTION_DOESNT_EXIST.getOutput());
        }catch (ArtworkDoesntExistInAuctionException e){
            System.out.print(Output.ARTWORK_DOESNT_EXIST_IN_AUCTION.getOutput());
        }catch (ArtworkWithNoBidsException e){
            System.out.print(Output.ARTWORK_HAS_NO_BIDS.getOutput());
        }
    }

    /**
     * Lists the information of all artworks by value.
     *
     * @param am Object of the AuctionManagement Class
     */
    private static void listArtworksByValue(AuctionManagement am) {
        try{
            Iterator<Entry<Integer, OrderedDictionary<String, Artwork>>> it = am.listArtworksByValue();
            System.out.println();
            while (it.hasNext()){
                Entry<Integer, OrderedDictionary<String, Artwork>> next = it.next();
                OrderedDictionary<String, Artwork> sameValue = next.getValue();
                Iterator<Entry<String, Artwork>> it2 = sameValue.iterator();
                while(it2.hasNext()) {
                    Entry<String, Artwork> next2 = it2.next();
                    Artwork art = next2.getValue();
                    System.out.printf(Output.ARTWORKS_BY_VALUE.getOutput(), art.getId(), art.getName(), art.getYear(),
                            art.getPriceSold(), art.getAuthor().getLogin(), art.getAuthor().getName());
                }
            }
        }catch (DoesntExistAnyArtworksSoldException e){
            System.out.print(Output.ANY_ARTWORK_WAS_SOLD.getOutput());
        }
    }


    /**
     * Terminates the execution of the program
     */
    private static void quit() {
        System.out.println(Output.QUIT.getOutput());
    }

    /**
     * Loads the AuctionManagement from the dat file DAT_FILE.
     *
     * @return the loaded AuctionManagement.
     */
    @SuppressWarnings("unchecked")
    private static AuctionManagement load(){
        try {
            ObjectInputStream file = new ObjectInputStream(new FileInputStream(DAT_FILE));
            AuctionManagement am = (AuctionManagement) file.readObject();
            file.close();
            return am;
        } catch (FileNotFoundException e) {
            return new AuctionManagementClass();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }

    /**
     * Saves the AuctionManagement in the dat file DAT_FILE.
     *
     * @param am AuctionManagement that is being saved.
     */
    private static void save(AuctionManagement am) {
        try {
            ObjectOutputStream file = new ObjectOutputStream(new FileOutputStream(DAT_FILE));
            file.writeObject(am);
            file.flush();
            file.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Gets a command.
     *
     * @param in Scanner that reads the user's inputs
     * @return the command
     */
    private static Command getCommand(Scanner in) {
        try {
            String c = in.next();
            return Command.valueOf(c.toUpperCase());
        } catch (IllegalArgumentException e) {
            return Command.UNKNOWN;
        }
    }
}
