package auctionManagement;

import java.io.Serializable;

/**
 * User private interface.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
interface PrivateUser extends User, Serializable {

    /**
     * Increments the number of active bids by 1
     */
    void incBid();

    /**
     * Decrements the number of active bids by 1
     */
    void remBid();
}
