package auctionManagement;

import java.io.Serializable;

/**
 * Artist private interface.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
interface PrivateArtist extends Artist, Serializable {

    /**
     * Increments the counter of artworks in auction by one
     */
    void incrementArtInAuctionCount();

    /**
     * Decrements the counter of artworks in auction by one
     */
    void decrementArtInAuctionCount();
}
