package auctionManagement;

import dataStructures.Iterator;

/**
 * ArtworkInAuction public interface.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public interface ArtworkInAuction {

    /**
     *
     * @return the artwork in question
     */
    Artwork getArtwork();

    /**
     *
     * @return the lowest price at which this artwork can be sold in this auction
     */
    int getMinimumPrice();

    /**
     *
     * @return the price of the highest bid that was made to this artwork in its auction
     */
    int getHighestPrice();

    /**
     *
     * @return the highest bid that was made to this artwork in its auction
     */
    Bid getHighestBid();

    /**
     *
     * @return true if this artwork has bids in the auction, false otherwise
     */
    boolean hasBids();

    /**
     *
     * @return an iterator that goes through all of this artwork's bids in this auction
     */
   Iterator<Bid> getIteratorBids();
}
