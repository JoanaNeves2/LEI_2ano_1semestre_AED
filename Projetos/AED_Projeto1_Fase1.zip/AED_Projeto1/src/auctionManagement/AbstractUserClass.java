package auctionManagement;

import dataStructures.DoubleList;

import java.io.Serial;

/**
 * Abstract class for the user. Resembles a user of the system.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
abstract class AbstractUserClass implements PrivateUser {

    /**
     * Serial Version UID
     */
    @Serial
    private static final long serialVersionUID = 0L;

    //Instance variables.
    final String login, name, email;
    final int age;
    DoubleList<Artwork> artworks;
    int countActiveBids;

    /**
     * Constructor
     *
     * @param login is the login of the user
     * @param name is the name of the user
     * @param age is the age of the user
     * @param email is the email of the user
     */
    AbstractUserClass(String login, String name, int age, String email){
        this.login = login;
        this.name = name;
        this.age = age;
        this.email = email;
        this.artworks = new DoubleList<>();
        this.countActiveBids = 0;
    }

    /**
     * constructor with only an argument, the login, to find the object
     *
     * @param login is the login of the user
     */
    AbstractUserClass(String login){
        this.login = login;
        this.name = null;
        this.age = 0;
        this.email = null;
        this.artworks = new DoubleList<>();

    }

    @Override
    public String getLogin(){
        return login;
    }

    @Override
    public String getName(){
        return name;
    }

    @Override
    public int getAge(){
        return age;
    }

    @Override
    public String getEmail(){
        return email;
    }

    @Override
    public void incBid(){
        countActiveBids++;
    }

    @Override
    public void remBid(){
        countActiveBids--;
    }

    @Override
    public boolean hasAtiveBids(){
        return countActiveBids != 0;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof User) {
            return ((User) o).getLogin().equals(this.getLogin());
        }
        return false;
    }
}
