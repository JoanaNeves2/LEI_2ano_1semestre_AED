package auctionManagement;

import dataStructures.DoubleList;
import enums.State;

import java.io.Serial;

/**
 * This class represents an artwork.
 * This class manages all the information about each artwork.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public class ArtworkClass implements PrivateArtwork {

    /**
     * Serial Version UID
     */
    @Serial
    private static final long serialVersionUID = 0L;

    //Instance Variables
    private final String id;
    private final String year;
    private final String name;
    private int priceSold;
    private State state;
    private final User author;
    private Bid highestBid;
    private DoubleList<Bid> bids;

    /**
     * Constructor
     *
     * @param id is the identifier of the artwork
     * @param author is the user who created the artwork
     * @param year is the year in which the artwork was created
     * @param name is the name of the artwork
     */
    public ArtworkClass(String id, User author, String year, String name) {
        this.id = id;
        this.author = author;
        this.year = year;
        this.name = name;
        this.state = State.AVAILABLE;
        this.highestBid = new BidClass();
        bids = new DoubleList<>();
        this.priceSold = 0;
    }

    /**
     * constructor with only an argument, the id, to find the object
     *
     * @param id is the identifier of the artwork
     */
    public ArtworkClass(String id) {
        this(id, null, null, null);
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public User getAuthor(){
        return author;
    }

    @Override
    public String getYear() {
        return year;
    }

    @Override
    public State getState() {
        return state;
    }

    @Override
    public int getPriceSold() {
        return priceSold;
    }

    @Override
    public void addBid(Bid newBid) {
        bids.addLast(newBid);
    }

    @Override
    public void setStatus(int price) {
        state = State.SOLD;
        priceSold = price;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof Artwork) {
            return ((Artwork) o).getId().equals(this.getId());
        }
        return false;
    }
}
