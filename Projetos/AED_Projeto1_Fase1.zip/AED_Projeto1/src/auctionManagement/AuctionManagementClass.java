package auctionManagement;

import exceptions.*;
import dataStructures.*;

import java.io.Serial;

/**
 * Auction management class that communicates with the Main.
 * Stores all the information regarding the users, the artworks
 * and the auctions.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public class AuctionManagementClass implements AuctionManagement {

    /**
     * Serial Version UID
     */
    @Serial
    private static final long serialVersionUID = 0L;

    //Constants
    private static final int MINIMUM_AGE = 18;

    //Instance Variables
    private final SearchableList<User> users;
    private final SearchableList<Artwork> artworks;
    private final SearchableList<Auction> auctions;

    /**
     * Constructor
     */
    @SuppressWarnings("unchecked")
    public AuctionManagementClass() {
        users = new SearchableDoubleList<>();
        artworks = new SearchableDoubleList<>();
        auctions = new SearchableDoubleList<>();
    }

    @Override
    public void addCollector(String login, String name, int age, String email)
            throws UserUnderageException, UserAlreadyExistsException {
        if (age < MINIMUM_AGE)
            throw new UserUnderageException();
        if (getUserByLogin(login) != null)
            throw new UserAlreadyExistsException();

        users.addLast(new CollectorClass(login, name, age, email));
    }

    @Override
    public void addArtist(String login, String name, String artistName, int age, String email)
            throws UserUnderageException, UserAlreadyExistsException {
        if (age < MINIMUM_AGE)
            throw new UserUnderageException();
        if (getUserByLogin(login) != null)
            throw new UserAlreadyExistsException();

        users.addLast(new ArtistClass(login, name, artistName, age, email));
    }

    @Override
    public void removeUser(String login)
            throws UserDoesntExistException, UserHasActiveBidsException, ArtistHasArtworkInAuctionException {
        User u = getUserByLogin(login);
        if (u == null)
            throw new UserDoesntExistException();

        if(u.hasAtiveBids())
            throw new UserHasActiveBidsException();

        if(u instanceof Artist) {
            if(((Artist) u).getArtInAuctionCount() == 0)
                removeArtistArtworks(u);
            else
                throw new ArtistHasArtworkInAuctionException();
        }
        users.removeElement(u);
    }

    @Override
    public void addWork(String artworkId, String loginAuthor, String year, String name)
            throws ArtworkAlreadyExistsException, UserDoesntExistException, UserIsNotAnArtistException {
        User user = getUserByLogin(loginAuthor);
        if (getArtworkById(artworkId) != null)
            throw new ArtworkAlreadyExistsException();
        if (user == null)
            throw new UserDoesntExistException();
        if(user instanceof Artist)
            artworks.addLast(new ArtworkClass(artworkId, user, year, name));
        else
            throw new UserIsNotAnArtistException();
    }

    @Override
    public User getInfoUser(String login)
            throws UserDoesntExistException {
        if (getUserByLogin(login) == null)
            throw new UserDoesntExistException();

        return getUserByLogin(login);
    }

    @Override
    public Artist getInfoArtist(String login)
            throws UserDoesntExistException, UserIsNotAnArtistException {
        User user = getUserByLogin(login);
        if (user == null)
            throw new UserDoesntExistException();
        if(user instanceof Artist)
            return (Artist) user;

        throw new UserIsNotAnArtistException();
    }

    @Override
    public Artwork getInfoArtwork(String artworkId)
            throws ArtworkDoesntExistException {
        Artwork artWork = getArtworkById(artworkId);
        if (artWork == null)
            throw new ArtworkDoesntExistException();

        return artWork;
    }

    @Override
    public void createAuction(String auctionID)
            throws AuctionAlreadyExistsException {

        if (getAuctionById(auctionID) != null)
            throw new AuctionAlreadyExistsException();

        auctions.addLast(new AuctionClass(auctionID));
    }

    @Override
    public void addArtworkToAuction(String auctionId, String artworkId, int minimumPrice)
            throws AuctionDoesntExistException, ArtworkDoesntExistException {
        if (getAuctionById(auctionId) == null)
            throw new AuctionDoesntExistException();
        if (getArtworkById(artworkId) == null)
            throw new ArtworkDoesntExistException();

        Artwork artwork = getArtworkById(artworkId);

        ((PrivateAuction) getAuctionById(auctionId)).addArtwork(artwork, minimumPrice);
    }

    @Override
    public void bid(String auctionId, String artworkId, String login, int value)
            throws UserDoesntExistException, AuctionDoesntExistException, ArtworkDoesntExistInAuctionException, BidBelowMinimumValueException {
        Auction auction = getAuctionById(auctionId);
        Artwork artwork = getArtworkById(artworkId);
        User user = getUserByLogin(login);

        if (user == null)
            throw new UserDoesntExistException();
        if (auction == null)
            throw new AuctionDoesntExistException();
        if (artwork == null || !auction.isArtworkInAuction(artwork))
            throw new ArtworkDoesntExistInAuctionException();
        if(value < auction.getArtworkMinimumValue(artwork))
            throw new BidBelowMinimumValueException();
        ((PrivateAuction) auction).addBid(value, user, artwork);
        ((PrivateUser) user).incBid();
    }

    @Override
    public Iterator<ArtworkInAuction> closeAuction(String auctionId)
            throws AuctionDoesntExistException {
        Auction auction = getAuctionById(auctionId);
        if(auction == null)
            throw new AuctionDoesntExistException();

        ((PrivateAuction) auction).close();
        return  auctions.removeElement(auction).getArtworkIterator();
    }

    @Override
    public Iterator<ArtworkInAuction> listAuctionWorks(String auctionID)
            throws AuctionEmptyException, AuctionDoesntExistException {

        Auction auction = getAuctionById(auctionID);
        if(auction == null)
            throw new AuctionDoesntExistException();
        if(auction.isEmpty())
            throw new AuctionEmptyException();

        return auction.getArtworkIterator();
    }

    @Override
    public Iterator<Bid> listBidsWorks(String auctionID, String artworkID)
            throws AuctionDoesntExistException, ArtworkDoesntExistInAuctionException, ArtworkWithNoBidsException {
        Auction auction = getAuctionById(auctionID);
        Artwork artwork = getArtworkById(artworkID);
        if(auction == null)
            throw new AuctionDoesntExistException();
        if(artwork == null || !auction.isArtworkInAuction(artwork))
            throw new ArtworkDoesntExistInAuctionException();
        if (!auction.hasArtInAuctionBids(artwork))
            throw new ArtworkWithNoBidsException();

        return auction.getArtworkInAuctionBidsIterator(artwork);
    }

    /**
     *
     * @param login is the login of the user we are looking for
     * @return the user object that corresponds to the given login
     */
    private User getUserByLogin(String login) {
        return users.findEquals(new CollectorClass(login));
    }

    /**
     *
     * @param artworkId is the id of the artwork we are looking for
     * @return the artwork object that corresponds to the given id
     */
    private Artwork getArtworkById(String artworkId) {
        return artworks.findEquals(new ArtworkClass(artworkId));
    }

    /**
     *
     * @param auctionId is the id of the auction we are looking for
     * @return the auction object that corresponds to the given id
     */
    private Auction getAuctionById(String auctionId) {
        return auctions.findEquals(new AuctionClass(auctionId));

    }

    /**
     * Removes all the artworks authored by a specified artist
     *
     * @param u the user whose artworks are going to be removed
     * @pre: User instanceof artist
     */
    private void removeArtistArtworks(User u){
        Iterator<Artwork> it = artworks.iterator();
        while(it.hasNext()){
            Artwork a = it.next();
            if(u.equals(a.getAuthor())){
                artworks.remove(a);
            }
        }
    }
}
