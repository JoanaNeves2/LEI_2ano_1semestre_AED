package auctionManagement;

import exceptions.*;
import dataStructures.*;

import java.io.Serial;

/**
 * This class represents an auction.
 * This class manages all the information about each auction.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public class AuctionClass implements PrivateAuction {

    /**
     * Serial Version UID
     */
    @Serial
    private static final long serialVersionUID = 0L;

    //Instance Variables
    private final String id;
    private final SearchableList<Artwork> artworks;
    private final SearchableList<ArtworkInAuction> artsInAuction;

    /**
     * Constructor
     *
     * @param id is the identifier of this auction
     */
    public AuctionClass(String id) {
        this.id = id;
        artworks = new SearchableDoubleList<>();
        artsInAuction = new SearchableDoubleList<>();
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public Boolean isEmpty() {
        return artworks.isEmpty();
    }

    @Override
    public Boolean hasArtInAuctionBids(Artwork artwork) {
        return artsInAuction.findEquals(new ArtworkInAuctionClass(artwork)).hasBids();
    }

    @Override
    public Iterator<ArtworkInAuction> getArtworkIterator() {
        return artsInAuction.iterator();
    }

    @Override
    public int getArtworkMinimumValue(Artwork artwork) {
        return artsInAuction.findEquals(new ArtworkInAuctionClass(artwork)).getMinimumPrice();
    }

    @Override
    public boolean isArtworkInAuction(Artwork artwork) {
        return artsInAuction.findEquals(new ArtworkInAuctionClass(artwork)) != null;
    }

    @Override
    public Iterator<Bid> getArtworkInAuctionBidsIterator(Artwork artwork) {
        return artsInAuction.findEquals(new ArtworkInAuctionClass(artwork)).getIteratorBids();
    }

    @Override
    public void addArtwork(Artwork newArtwork, int minimumPrice) {
        if (artworks.findEquals(newArtwork) == null) {
            artworks.addLast(newArtwork);
            artsInAuction.addLast(new ArtworkInAuctionClass(newArtwork, minimumPrice));
            ((PrivateArtist) newArtwork.getAuthor()).incrementArtInAuctionCount();
        }
    }

    @Override
    public void addBid(int value, User bidder, Artwork artWork) throws BidBelowMinimumValueException {
        Bid newBid = new BidClass(value, bidder, this);
        ArtworkInAuction art = artsInAuction.findEquals(new ArtworkInAuctionClass(artWork));
        ((PrivateArtworkInAuction) art).addBid(newBid);
    }

    @Override
    public void close() {
        Iterator<ArtworkInAuction> itArtsInAuction = artsInAuction.iterator();

        while (itArtsInAuction.hasNext()){
            ArtworkInAuction next = itArtsInAuction.next();
            int price = next.getHighestPrice();
            if(next.hasBids() && (price >= next.getMinimumPrice())) {
                ((PrivateArtwork) next.getArtwork()).setStatus(price);
            }
            ((PrivateArtworkInAuction) (next)).removeUsersBids();
            ((PrivateArtist) next.getArtwork().getAuthor()).decrementArtInAuctionCount();
        }
    }


    @Override
    public boolean equals(Object o) {
        if (o instanceof Auction) {
            return ((Auction) o).getId().equals(this.getId());
        }
        return false;
    }


}
