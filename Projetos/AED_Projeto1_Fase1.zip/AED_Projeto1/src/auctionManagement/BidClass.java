package auctionManagement;

import java.io.Serial;

/**
 * This class represents the bids that are made in each auction to each artwork.
 * This class manages all the information about each bid.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
class BidClass implements PrivateBid {

    /**
     * Serial Version UID
     */
    @Serial
    private static final long serialVersionUID = 0L;

    //Constants
    public static final int ZERO = 0;

    //Instance Variables
    private final int value;
    private final User bidder;
    private final Auction auction;

    /**
     * Constructor
     *
     * @param value is the value of the bid we want to create
     * @param bidder is the user that made this sales proposal
     * @param auction is the auction at which the bidder made this bid
     */
    public BidClass(int value, User bidder, Auction auction){
        this.value = value;
        this.bidder = bidder;
        this.auction = auction;
    }

    /**
     * constructor with only an argument, value, to initialize the highest Bid on all the artworkInAuction
     * when which one is initialized too
     */
    public BidClass(){
        this(ZERO, null, null);
    }

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public User getBidder() {
        return bidder;
    }

    @Override
    public void removeBid() {
        ((PrivateUser) bidder).remBid();
    }
}
