package auctionManagement;

import exceptions.*;

import java.io.Serializable;

/**
 * Auction private interface.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
interface PrivateAuction extends Auction, Serializable {

    /**
     * Adds a new artwork to the auction
     *
     * @param newArtwork is the artwork we want to add to this auction
     * @param minimumPrice is the minimum price at which this newArtwork can be sold in this auction
     * @pre: isArtworkInAuction(Artwork artwork)
     */
    void addArtwork(Artwork newArtwork, int minimumPrice);

    /**
     * Adds a new bid to a specific artwork in this auction
     *
     * @param value is the value of the new bid
     * @param bidder is the user who made the bid (sales proposal)
     * @param artWork is the artwork to which the bid will be added to
     * @throws BidBelowMinimumValueException if the new bid value if below the minimumPrice
     * @pre: bidder!=null && isArtworkInAuction(Artwork artwork) && value < artwork.getMinimumPrice()
     */
    void addBid(int value, User bidder, Artwork artWork) throws BidBelowMinimumValueException;

    /**
     * Closes the auction by going through all the artworks in it,
     * setting their highest bid value and status, and removing those bids from their users
     */
    void close();
}
