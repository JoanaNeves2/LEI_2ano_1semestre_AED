package auctionManagement;

import exceptions.*;
import dataStructures.Iterator;

import java.io.Serializable;

/**
 * Auction management interface.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public interface AuctionManagement extends Serializable {

    /**
     * Creates a new collector if the user doesn't already exist and if the age isn't below 18 years
     *
     * @param login is the identifier/login of the collector
     * @param name is the name of the collector
     * @param age is the age of the collector
     * @param email is the email of the collector
     * @throws UserUnderageException if the collector has below 18 years old
     * @throws UserAlreadyExistsException if the user already exists in the system
     */
    void addCollector(String login, String name, int age, String email) throws UserUnderageException, UserAlreadyExistsException;

    /**
     * Creates a new artist if the user doesn't already exist and if the age isn't below 18 years
     *
     * @param login is the identifier/login of the artist
     * @param name is the name of the artist
     * @param artistName is the artist name of the artist
     * @param age is the age of the artist
     * @param email is the email of the artist
     * @throws UserUnderageException if the artist has below 18 years old
     * @throws UserAlreadyExistsException if the user already exists in the system
     */
    void addArtist(String login, String name, String artistName, int age, String email) throws UserUnderageException, UserAlreadyExistsException;

    /**
     * Removes a user from the system
     *
     * @param login is the identifier/login of the user
     * @throws UserDoesntExistException if the user doesn't exist in the system
     * @throws UserHasActiveBidsException if the user has active bids
     * @throws ArtistHasArtworkInAuctionException if the user is an artist and if he has any of his artwork in any auction
     */
    void removeUser(String login) throws UserDoesntExistException, UserHasActiveBidsException, ArtistHasArtworkInAuctionException;

    /**
     * Adds a new artwork to the system
     *
     * @param idWork is the identifier of the artwork
     * @param loginAuthor is the identifier/login of the user
     * @param year is the year in which the artwork was created
     * @param name is the name of the artwork
     * @throws ArtworkAlreadyExistsException if the artwork already exists in the system
     * @throws UserDoesntExistException if the user doesn't exist in the system
     * @throws UserIsNotAnArtistException if the user that corresponds to the given login isn't an artist
     */
    void addWork(String idWork, String loginAuthor, String year, String name) throws ArtworkAlreadyExistsException, UserDoesntExistException, UserIsNotAnArtistException;

    /**
     * Returns the specified user if it exists in the system
     *
     * @param login is the identifier/login of the user we are looking for
     * @return the specified user
     * @throws UserDoesntExistException if the user doesn't exist in the system
     */
    User getInfoUser(String login) throws UserDoesntExistException;

    /**
     * Returns the specified artist if it exists in the system
     *
     * @param login is the identifier/login of the artist we are looking for
     * @return the specified artist
     * @throws UserDoesntExistException if the user doesn't exist in the system
     * @throws UserIsNotAnArtistException if the user that corresponds to the given login isn't an artist
     */
    Artist getInfoArtist(String login) throws UserDoesntExistException, UserIsNotAnArtistException;

    /**
     * Returns the specified artwork if it exists in the system
     *
     * @param idArtwork is the identifier of the artwork we can look for information
     * @return an artwork
     * @throws ArtworkDoesntExistException if the artwork doesn't exist into the system
     */
    Artwork getInfoArtwork(String idArtwork) throws ArtworkDoesntExistException;

    /**
     * Creates a new auction if the auction doesn't already exist in the system
     *
     * @param auctionID is the identifier of the auction we want to create
     * @throws AuctionAlreadyExistsException if the auction already exist in the system
     */
    void createAuction(String auctionID) throws AuctionAlreadyExistsException;

    /**
     * Adds an already existing artwork to an also already existing auction, with a minimum bid value
     *
     * @param auctionId is the identifier of the auction which we want to add an artwork to
     * @param artworkId is the identifier of the artwork we want to add
     * @param minimumBid is the minimum value at which the artwork can be sold in the auction
     * @throws AuctionDoesntExistException if the auction doesn't exist in the system
     * @throws ArtworkDoesntExistException if the artwork doesn't exist in the system
     */
    void addArtworkToAuction(String auctionId, String artworkId, int minimumBid) throws AuctionDoesntExistException, ArtworkDoesntExistException;

    /**
     * Adds a new bid to a specific artwork in a specific auction.
     *
     * @param auctionId is the identifier of the auction that has the artwork
     * @param artworkId is the identifier of the artwork
     * @param login is the identifier of the user who made the bid
     * @param value is the value of the bid
     * @throws UserDoesntExistException if the user doesn't exist in the system
     * @throws AuctionDoesntExistException if the auction doesn't exist in the system
     * @throws ArtworkDoesntExistInAuctionException if the artwork doesn't exist in the specified auction
     * @throws BidBelowMinimumValueException if the value is below the minimum value of the artwork in this auction
     */
    void bid(String auctionId, String artworkId, String login, int value) throws UserDoesntExistException, AuctionDoesntExistException, ArtworkDoesntExistInAuctionException, BidBelowMinimumValueException;

    /**
     * Closes a specific auction, and returns an iterator of all the artworks that were being sold in it.
     *
     * @param auctionId is the identifier of the auction we want to close
     * @return an iterator that goes through all the artwork that were in the auction
     * @throws AuctionDoesntExistException if the auction doesn't exist in the system
     */
    Iterator<ArtworkInAuction> closeAuction(String auctionId) throws AuctionDoesntExistException;

    /**
     * Returns an iterator of all the artworks that are being sold in a specific auction
     *
     * @param auctionID is the identifier of the auction
     * @return an iterator that goes through all the artworks in the specified auction
     * @throws AuctionEmptyException if the auction has no artworks
     * @throws AuctionDoesntExistException if the auction doesn't exist in the system
     */
    Iterator<ArtworkInAuction> listAuctionWorks(String auctionID) throws AuctionEmptyException, AuctionDoesntExistException;

    /**
     * Returns an iterator of all the bids made to a specific artwork in a specific auction.
     *
     * @param auctionID is the identifier of the auction that has the artwork
     * @param artworkID is the identifier of the artwork
     * @return an iterator goes through all the bids of the specified artwork in the specified auction
     * @throws AuctionDoesntExistException if the auction doesn't exist in the system
     * @throws ArtworkDoesntExistInAuctionException if the artwork doesn't exist in the auction
     * @throws ArtworkWithNoBidsException if the artwork doesn't have any bids in this auction
     */
    Iterator<Bid> listBidsWorks(String auctionID, String artworkID) throws AuctionDoesntExistException,ArtworkDoesntExistInAuctionException,ArtworkWithNoBidsException;
}
