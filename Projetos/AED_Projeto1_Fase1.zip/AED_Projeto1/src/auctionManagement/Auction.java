package auctionManagement;

import dataStructures.Iterator;

/**
 * Auction public interface.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public interface Auction {

    /**
     *
     * @return the identifier of the auction
     */
    String getId();

    /**
     *
     * @return true if the auction doesn't have any artwork in it, false otherwise
     */
    Boolean isEmpty();

    /**
     *
     * @param artwork is the artwork from which we want to know the number of bids
     * @return true if the artwork has any bids in this auction, false otherwise
     * @pre: isArtworkInAuction(Artwork artwork)
     */
    Boolean hasArtInAuctionBids(Artwork artwork);

    /**
     *
     * @return an iterator that goes through all the artworks in this auction
     */
    Iterator<ArtworkInAuction> getArtworkIterator();

    /**
     *
     * @param artwork is the artwork from which we want to know the minimum price at which it can be sold in this auction
     * @return the minimum price at which the artwork can be sold in this auction
     * @pre: isArtworkInAuction(Artwork artwork)
     */
    int getArtworkMinimumValue(Artwork artwork);

    /**
     *
     * @param artwork is the artwork we want to check whether it's in the auction
     * @return true if the artwork is in this auction, false otherwise
     */
    boolean isArtworkInAuction(Artwork artwork);

    /**
     *
     * @param artwork is the artwork from which we want to get the bids iterator
     * @return an iterator that goes through all the bids of the specified artwork
     * @pre: isArtworkInAuction(Artwork artwork)
     */
    Iterator<Bid> getArtworkInAuctionBidsIterator(Artwork artwork);
}
