package auctionManagement;

/**
 * User public interface.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public interface User {

    /**
     *
     * @return the login of the user
     */
    String getLogin();

    /**
     *
     * @return the name of the user
     */
    String getName();

    /**
     *
     * @return the age of the user
     */
    int getAge();

    /**
     *
     * @return the email of the user
     */
    String getEmail();

    /**
     *
     * @return true if the user has active bids, false otherwise
     */
    boolean hasAtiveBids();
}
