package auctionManagement;

import java.io.Serializable;

/**
 * Artwork private interface.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
interface PrivateArtwork extends Artwork, Serializable {

    /**
     * Adds a new bid to this artwork's bids collection
     *
     * @param newBid is the new sales proposal for this artwork
     */
    void addBid(Bid newBid);

    /**
     * Changes the state from available to sold, and updates the priceSold
     *
     * @param price is the price at which the artwork was sold
     */
    void setStatus(int price);
}
