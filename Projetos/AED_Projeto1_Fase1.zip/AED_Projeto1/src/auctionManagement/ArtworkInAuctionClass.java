package auctionManagement;

import exceptions.*;
import dataStructures.*;

import java.io.Serial;

/**
 * This class represents an artwork when it is in an auction.
 * This class manages all the information about the bids that are made
 * to its artwork in its auction.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public class ArtworkInAuctionClass implements PrivateArtworkInAuction{

    /**
     * Serial Version UID
     */
    @Serial
    private static final long serialVersionUID = 0L;

    //Instance Variables
    private final Artwork artwork;
    private final int minimumPrice;
    private int highestPrice;
    private SearchableList<Bid> bids;
    private Bid highestBid;

    /**
     * Constructor
     *
     * @param artwork is one of the artworks that is being sold in the auction
     * @param minimumPrice is the lowest price at which this artwork can be sold in the auction
     */
    public ArtworkInAuctionClass(Artwork artwork, int minimumPrice){
        this.artwork = artwork;
        this.minimumPrice = minimumPrice;
        this.highestPrice = 0;
        bids = new SearchableDoubleList<>();
        highestBid = null;
    }

    /**
     * Constructor with only one argument, the artwork
     *
     * @param artwork is one of the artworks that is being sold in the auction
     */
    public ArtworkInAuctionClass(Artwork artwork){
        this(artwork, 0);
    }

    @Override
    public Artwork getArtwork() {
        return artwork;
    }

    @Override
    public int getMinimumPrice() {
        return minimumPrice;
    }

    @Override
    public int getHighestPrice() {
        return highestPrice;
    }

    @Override
    public Bid getHighestBid() {
        return highestBid;
    }

    @Override
    public boolean hasBids() {
        return !bids.isEmpty();
    }

    @Override
    public Iterator<Bid> getIteratorBids() {
        return bids.iterator();
    }

    @Override
    public void addBid(Bid newBid) throws BidBelowMinimumValueException {
        if(newBid.getValue() < minimumPrice)
            throw new BidBelowMinimumValueException();
        ((PrivateArtwork) artwork).addBid(newBid);
        bids.addLast(newBid);
        int newBidValue = newBid.getValue();
        if(newBidValue > highestPrice) {
            highestPrice = newBidValue;
            highestBid = newBid;
        }

    }

    @Override
    public void removeUsersBids() {
        Iterator<Bid> itBids = bids.iterator();

        while (itBids.hasNext()){
            ((PrivateBid) itBids.next()).removeBid();

        }
    }

    @Override
    public boolean equals(Object o){
        if (o instanceof ArtworkInAuction) {
            return ((ArtworkInAuction) o).getArtwork().equals(this.artwork);
        }
        return false;
    }
}
