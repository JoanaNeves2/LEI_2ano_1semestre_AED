package auctionManagement;

import exceptions.BidBelowMinimumValueException;

import java.io.Serializable;

/**
 * ArtworkInAuction private interface.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
interface PrivateArtworkInAuction extends ArtworkInAuction, Serializable {

    /**
     * Adds a new bid to both this artworkInAuction's, and its artwork's bids collections
     *
     * @param newBid is the new sales proposal for this artwork
     * @throws BidBelowMinimumValueException if the new bid value if below the minimumPrice
     */
    void addBid(Bid newBid) throws BidBelowMinimumValueException;

    /**
     * Removes the bids of this artworkInAuction when the auction is closed
     */
    void removeUsersBids();
}
