package auctionManagement;

import java.io.Serial;

/**
 * This class represents a user of type artist.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public class ArtistClass extends AbstractUserClass implements PrivateArtist {

    /**
     * Serial Version UID
     */
    @Serial
    private static final long serialVersionUID = 0L;

    //Instance Variables
    private final String artistName;
    private int artInAuctionCount;

    /**
     * Constructor
     *
     * @param login is the login of the user
     * @param name is the name of the user
     * @param artistName is the artist name of the artist
     * @param age is the age of the user
     * @param email is the email of the user
     */
    public ArtistClass(String login, String name, String artistName, int age, String email){
        super(login, name, age, email);
        this.artistName = artistName;
        artInAuctionCount = 0;
    }


    @Override
    public String getArtistName() {
        return artistName;
    }

    @Override
    public int getArtInAuctionCount() {
        return artInAuctionCount;
    }

    @Override
    public void incrementArtInAuctionCount() {
        artInAuctionCount++;
    }

    @Override
    public void decrementArtInAuctionCount(){
        artInAuctionCount--;
    }
}
