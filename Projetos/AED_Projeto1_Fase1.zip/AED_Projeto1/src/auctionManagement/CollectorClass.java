package auctionManagement;

import java.io.Serial;

/**
 * This class represents a user of type collector.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public class CollectorClass extends AbstractUserClass implements PrivateCollector {

    /**
     * Serial Version UID
     */
    @Serial
    private static final long serialVersionUID = 0L;

    /**
     *
     * @param login is the login of the user
     * @param name is the name of the user
     * @param age is the age of the user
     * @param email is the email of the user
     */
    public CollectorClass(String login, String name, int age, String email){
        super(login, name, age, email);
    }

    /**
     * constructor with only an argument, the login, to find the object
     *
     * @param login is the login of the user
     */
    public CollectorClass(String login){
        super(login);
    }

    @Override
    public String getLogin() {
        return login;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getAge() {
        return age;
    }

    @Override
    public String getEmail() {
        return email;
    }
}
