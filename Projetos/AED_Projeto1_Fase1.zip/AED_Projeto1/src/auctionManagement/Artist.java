package auctionManagement;

/**
 * Artist public interface.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public interface Artist extends User{

    /**
     *
     * @return the artist name of the artist
     */
    String getArtistName();

    /**
     *
     * @return the number of artworks which this artist has in auction
     */
    int getArtInAuctionCount();
}
