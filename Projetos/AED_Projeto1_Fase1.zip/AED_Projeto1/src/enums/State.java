package enums;

/**
 * Enum with all the artwork states of this implementation.
 *
 * @author Joana Simões Neves (65441) js.neves@campus.fct.unl.pt
 * @author Rui Xavier (65815) ra.xavier@campus.fct.unl.pt
 */
public enum State {

    SOLD,
    AVAILABLE;
}
