package exceptions;

public class ArtworkDoesntExistInAuctionException extends Exception{
}
