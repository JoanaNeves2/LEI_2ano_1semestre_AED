package exceptions;

public class AuctionAlreadyExistsException extends Exception{
}
