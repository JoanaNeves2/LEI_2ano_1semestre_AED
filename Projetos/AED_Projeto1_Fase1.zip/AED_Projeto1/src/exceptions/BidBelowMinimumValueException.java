package exceptions;

public class BidBelowMinimumValueException extends Exception{
}
