package exceptions;

public class UserIsNotAnArtistException extends Exception{
}
