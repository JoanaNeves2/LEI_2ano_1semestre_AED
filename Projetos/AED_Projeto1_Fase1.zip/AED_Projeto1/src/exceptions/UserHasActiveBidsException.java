package exceptions;

public class UserHasActiveBidsException extends Exception{
}
