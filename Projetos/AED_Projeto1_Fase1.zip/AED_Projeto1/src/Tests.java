/**
 * @author Carla Ferreira
 *
 */
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.PrintStream;
import java.nio.file.Files;
import java.util.Locale;

import org.junit.Before;
import org.junit.Test;

/**
 * A classe Tests especifica um conjunto de testes implementado recorrendo 'a ferramenta
 * JUnit. Estes testes usam como input os ficheiros de teste do Mooshak, gerando, como
 * output, o resultado esperado na execucao desses testes.
 * A classe esta implementada para os testes do problema do CloudSharing.
 * Para poder usar esta classe tem de incluir no seu ambiente de execucao a biblioteca JUnit 4.
 * Veja como o pode fazer na primeira aula pratica do semestre!
 */
public class Tests {
    /**
     * Use as linhas que se seguem para especificar os testes que vai realizar.
     * Por exemplo, o resultado esperado para o teste
     * 1_in_base.txt 'e 1_out_base.txt . Nao tem de fazer mais nada no resto da classe.
     * Basta configurar esta sequencia de testes!
     */

    /**
     * Testa o comando addUser.
     */
  //  @Test public void test00() { test("0_addUser_IN.txt","0_addUser_OUT.txt"); }
    /**
     * Testa o comando removeUser.
     */
  //  @Test public void test02() { test("2_removeUser_IN.txt","2_removeUser_OUT.txt"); }
    /**
     * Testa o comando addArtist.
     */
  //  @Test public void test01() { test("1_addArtist_IN.txt","1_addArtist_OUT.txt"); }
    /**
     * Testa o comando addWork.
     */
  //  @Test public void test03() { test("3_addWork_IN.txt","3_addWork_OUT.txt"); }
    /**
     * Testa o comando infoUser.
     */
  //  @Test public void test04() { test("4_infoUser_IN.txt","4_infoUser_OUT.txt"); }
    /**
     * Testa o comando infoArtist.
     */
 //   @Test public void test05() { test("5_infoArtist_IN.txt","5_infoArtist_OUT.txt"); }
    /**
     * Testa o comando infoWork.
     */
  //  @Test public void test06() { test("6_infoWork_IN.txt","6_infoWork_OUT.txt"); }
    /**
     * Testa o comando createAuction.
     */
 //   @Test public void test07() { test("7_createAuction_IN.txt","7_createAuction_OUT.txt"); }
    /**
     * Testa o comando addWorkAuction.
     */
 //   @Test public void test08() { test("8_addWorkAuction_IN.txt","8_addWorkAuction_OUT.txt"); }
    /**
     * Testa o comando bid.
     */
  //  @Test public void test09() { test("9_bid_IN.txt","9_bid_OUT.txt"); }
    /**
     * Testa o comando closeAuction.
     */
 //   @Test public void test10() { test("10_closeAuction_IN.txt","10_closeAuction_OUT.txt"); }
    /**
     * Testa o comando listArtistWork.
     */
  //  @Test public void test12() { test("12_listArtistWork.txt","12_listArtistWork_OUT.txt"); }
    /**
     * Testa o comando listAuctionWork.
     */
  //  @Test public void test11() { test("11_listAuctionWork_IN.txt","11_listAuctionWork_OUT.txt"); }
    /**
     * Testa o comando listBidsWork.
     */
 //   @Test public void test13() { test("13_listBidsWork_OUT.txt","13_listBidsWork_OUT.txt"); }
    /**
     * Testa o comando listWorkByValue.
     */
 //   @Test public void test14() { test("14_listWorkByValue_IN.txt","14_listWorkByValue_OUT.txt"); }
    /**
     * Testa o comando quit.
     */
 //   @Test public void test15() { test("15_quit_IN.txt","15_quit_OUT.txt"); }

    @Test public void test01() { test("1_in.txt","1_out.txt"); }
    @Test public void test02() { test("2_in.txt","2_out.txt"); }
    @Test public void test03() { test("3_in.txt","3_out.txt"); }
    @Test public void test04() { test("4_in.txt","4_out.txt"); }
    @Test public void test05() { test("5_in.txt","5_out.txt"); }
    @Test public void test06() { test("6_in.txt","6_out.txt"); }
    @Test public void test07() { test("7_in.txt","7_out.txt"); }




    private static final File BASE = new File("tests");

    private PrintStream consoleStream;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

    @Before
    public void setup() {
        consoleStream = System.out;
        System.setOut(new PrintStream(outContent));
    }

    public void test(String intput, String output) {
        test(new File(BASE, intput), new File(BASE, output));
    }

    public void test(File input, File output) {
        consoleStream.println("Testing!");
        consoleStream.println("Input: " + input.getAbsolutePath());
        consoleStream.println("Output: " + output.getAbsolutePath());

        String fullInput = "", fullOutput = "";
        try {
            fullInput = new String(Files.readAllBytes(input.toPath()));
            fullOutput = new String(Files.readAllBytes(output.toPath()));
            consoleStream.println("INPUT ============");
            consoleStream.println(new String(fullInput));
            consoleStream.println("OUTPUT ESPERADO =============");
            consoleStream.println(new String(fullOutput));
            consoleStream.println("OUTPUT =============");
        } catch(Exception e) {
            e.printStackTrace();
            fail("Erro a ler o ficheiro");
        }

        try {
            Locale.setDefault(Locale.US);
            System.setIn(new FileInputStream(input));
            Class<?> mainClass = Class.forName("Main");
            mainClass.getMethod("main", String[].class).invoke(null, new Object[] { new String[0] });
        } catch (Exception e) {
            e.printStackTrace();
            fail("Erro no programa");
        } finally {
            byte[] outPrintBytes = outContent.toByteArray();
            consoleStream.println(new String(outPrintBytes));

            assertEquals(removeCarriages(fullOutput), removeCarriages(new String(outContent.toByteArray())));
        }
    }

    private static String removeCarriages(String s) {
        return s.replaceAll("\r\n", "\n");
    }

}