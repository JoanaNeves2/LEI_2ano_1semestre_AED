package exceptions;

public class UserUnderageException extends Exception{
}
