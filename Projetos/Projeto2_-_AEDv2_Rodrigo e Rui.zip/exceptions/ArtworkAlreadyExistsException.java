package exceptions;

public class ArtworkAlreadyExistsException extends Exception{
}
