package exceptions;

public class ArtistHasArtworkInAuctionException extends Exception{
}
