package exceptions;

public class NoSoldWorksException extends Exception{
}
