package exceptions;

public class ArtworkHasNoBidsException extends Exception{
}
