package exceptions;

public class ArtistHasNoWorksException extends Exception {
}
