package exceptions;

public class AuctionEmptyException extends Exception{
}
