package exceptions;

public class UserAlreadyExistsException extends Exception{
}
