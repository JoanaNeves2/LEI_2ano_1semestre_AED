package dataStructures.exceptions;

public class EmptyDictionaryException extends RuntimeException{

    static final long serialVersionUID = 0L;
}

