package auctionManagment;

import java.io.Serializable;

interface PrivateCollector extends Collector, Serializable {
}
