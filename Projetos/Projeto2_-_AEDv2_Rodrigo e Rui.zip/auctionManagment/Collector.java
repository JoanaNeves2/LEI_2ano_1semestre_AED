package auctionManagment;

public interface Collector extends User{
}
