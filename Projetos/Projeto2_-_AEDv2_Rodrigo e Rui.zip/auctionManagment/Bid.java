package auctionManagment;

public interface Bid {
    int getVal();

    String getUserID();

    String getUsername();

    String getArtworkID();
}
