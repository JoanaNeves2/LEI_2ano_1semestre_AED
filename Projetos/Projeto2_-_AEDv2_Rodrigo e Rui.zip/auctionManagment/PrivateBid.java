package auctionManagment;

import java.io.Serializable;

interface PrivateBid extends Bid, Serializable {
}
